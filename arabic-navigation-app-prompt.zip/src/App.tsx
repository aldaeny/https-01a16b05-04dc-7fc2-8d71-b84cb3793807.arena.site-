import { useCallback, useEffect, useState } from "react";
import { Home as HomeIcon, Search, Bookmark, Settings as SettingsIcon, WifiOff, X } from "lucide-react";
import type { Place, TabId } from "./types";
import { GOVERNORATES } from "./data/iraq";
import Home from "./pages/Home";
import Explore from "./pages/Explore";
import Saved from "./pages/Saved";
import Settings from "./pages/Settings";
import { useOnline, useSettings } from "./store/storage";
import { LogoIcon } from "./components/Logo";
import { cn } from "./utils/cn";

const TABS: { id: TabId; label: string; icon: typeof HomeIcon }[] = [
  { id: "home", label: "الرئيسية", icon: HomeIcon },
  { id: "explore", label: "استكشف", icon: Search },
  { id: "saved", label: "محفوظاتي", icon: Bookmark },
  { id: "settings", label: "الإعدادات", icon: SettingsIcon },
];

export default function App() {
  const { settings, update } = useSettings();
  const online = useOnline(settings.offlineMode);
  const [tab, setTab] = useState<TabId>("home");
  const [exploreQuery, setExploreQuery] = useState("");
  const [pendingDest, setPendingDest] = useState<Place | null>(null);

  const defGov = GOVERNORATES.find((g) => g.id === settings.defaultGov) ?? GOVERNORATES[0];
  const [center, setCenter] = useState<[number, number]>([defGov.lat, defGov.lon]);
  const [zoom, setZoom] = useState(defGov.zoom);
  const [userLoc, setUserLoc] = useState<[number, number] | null>(null);
  const [locating, setLocating] = useState(false);
  const [showOfflineTip, setShowOfflineTip] = useState(true);

  const [onboarded, setOnboarded] = useState(() => {
    try { return localStorage.getItem("irqnav:onboarded:v1") === "1"; } catch { return true; }
  });
  const [onStep, setOnStep] = useState(0);

  const locate = useCallback(() => {
    setLocating(true);
    if (!("geolocation" in navigator)) {
      setLocating(false);
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const c: [number, number] = [pos.coords.latitude, pos.coords.longitude];
        setUserLoc(c);
        setCenter(c);
        setZoom(14);
        setLocating(false);
      },
      () => setLocating(false),
      { enableHighAccuracy: true, timeout: 8000 }
    );
  }, []);

  // محاولة تحديد الموقع عند أول فتح
  useEffect(() => {
    if (onboarded && !userLoc) locate();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [onboarded]);

  const goExplore = (q = "") => {
    setExploreQuery(q);
    setTab("explore");
  };
  const openPlace = (p: Place) => {
    setPendingDest(p);
    setTab("home");
  };

  const finishOnboarding = () => {
    try { localStorage.setItem("irqnav:onboarded:v1", "1"); } catch { /* noop */ }
    setOnboarded(true);
  };

  const ONBOARD = [
    {
      emoji: "🧭", title: "أهلًا بك في السحاب Cloud GPS",
      sub: "ملاحة عربية صُممت للعراق: من بغداد إلى البصرة، ومن الموصل إلى الأهوار — بلا حسابات وبلا تعقيد.",
    },
    {
      emoji: "✨", title: "ابحث بلهجتك",
      sub: "اكتب «مطعم مشويات قرب المنصور» أو «صيدلية خافرة» وسيفهم الذكاء الاصطناعي قصدك ويقترح الأقرب.",
    },
    {
      emoji: "🛣️", title: "مسارات حية وتوجيه صوتي",
      sub: "مسارات حقيقية عبر OSRM مع توجيه صوتي بالعربية، وحفظ تلقائي يعمل دون اتصال.",
    },
    {
      emoji: "🔒", title: "خصوصيتك أولًا",
      sub: "كل بياناتك على جهازك فقط. لا حساب، لا تتبّع، وزر واحد يمسح كل شيء.",
    },
  ];

  return (
    <div dir="rtl" className="flex h-dvh w-full justify-center bg-ink-950">
      {/* إطار التطبيق — بعرض جوال مركزي على الشاشات الكبيرة */}
      <div className="relative flex h-full w-full max-w-[480px] flex-col overflow-hidden bg-sand-50 shadow-2xl sm:my-0 md:my-4 md:h-[calc(100dvh-2rem)] md:rounded-[32px] md:ring-8 md:ring-black/60">
        {/* شريط عدم الاتصال */}
        {!online && showOfflineTip && (
          <div className="z-50 flex items-center gap-2 bg-amber-400 px-4 py-2 text-ink-950">
            <WifiOff size={15} className="shrink-0" />
            <p className="flex-1 text-[12px] font-black">
              {settings.offlineMode ? "وضع عدم الاتصال مفعّل — القاعدة المحلية والمسارات المخزّنة" : "لا يوجد اتصال — التطبيق يعمل محليًا"}
            </p>
            <button onClick={() => setShowOfflineTip(false)} className="rounded-full bg-black/10 p-1">
              <X size={13} />
            </button>
          </div>
        )}

        {/* المحتوى */}
        <div className="relative min-h-0 flex-1">
          {tab === "home" && (
            <Home
              settings={settings}
              online={online}
              center={center}
              setCenter={setCenter}
              zoom={zoom}
              setZoom={setZoom}
              userLoc={userLoc}
              locate={locate}
              locating={locating}
              goExplore={goExplore}
              pendingDest={pendingDest}
              setPendingDest={setPendingDest}
            />
          )}
          {tab === "explore" && (
            <div key={exploreQuery} className="h-full bg-sand-50">
              <Explore
                settings={settings}
                online={online}
                userLoc={userLoc}
                initialQuery={exploreQuery}
                onOpenPlace={openPlace}
                onRouteTo={openPlace}
              />
            </div>
          )}
          {tab === "saved" && (
            <div className="h-full bg-sand-50">
              <Saved onOpenPlace={openPlace} onRouteTo={openPlace} />
            </div>
          )}
          {tab === "settings" && (
            <div className="h-full bg-sand-50">
              <Settings settings={settings} update={update} online={online} />
            </div>
          )}
        </div>

        {/* شريط التنقل السفلي */}
        <nav data-bottom-nav className="relative z-50 border-t border-slate-900/5 bg-white/95 px-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] pt-2 backdrop-blur">
          <div className="grid grid-cols-4 gap-1">
            {TABS.map((t) => {
              const active = tab === t.id;
              return (
                <button
                  key={t.id}
                  onClick={() => { setTab(t.id); if (t.id === "explore") setExploreQuery(""); }}
                  className={cn(
                    "relative flex flex-col items-center gap-1 rounded-2xl py-2 transition-all active:scale-95",
                    active ? "text-ink-900" : "text-slate-400"
                  )}
                >
                  {active && (
                    <span className="absolute -top-2 h-1 w-10 rounded-full bg-gold-400" />
                  )}
                  <span className={cn(
                    "flex h-10 w-12 items-center justify-center rounded-2xl transition-all",
                    active ? "bg-ink-900 text-gold-300 shadow-card" : "bg-transparent"
                  )}>
                    <t.icon size={20} strokeWidth={active ? 2.4 : 2} />
                  </span>
                  <span className={cn("text-[11px]", active ? "font-black" : "font-bold")}>{t.label}</span>
                </button>
              );
            })}
          </div>
        </nav>

        {/* الترحيب الأول */}
        {!onboarded && (
          <div className="absolute inset-0 z-[60] flex flex-col bg-ink-950/98 p-6 text-white backdrop-blur">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-white shadow-card">
                  <LogoIcon size={34} />
                </div>
                <span className="text-[15px] font-black" dir="auto">السحاب Cloud GPS</span>
              </div>
              <button onClick={finishOnboarding} className="rounded-full bg-white/10 px-4 py-2 text-[12px] font-bold text-white/70">
                تخطي
              </button>
            </div>
            <div className="flex flex-1 flex-col items-center justify-center text-center">
              <div key={onStep} className="animate-pop">
                <div className="mx-auto flex h-32 w-32 items-center justify-center rounded-[36px] bg-white text-6xl shadow-app ring-4 ring-gold-400/40">
                  {onStep === 0 ? <LogoIcon size={104} /> : ONBOARD[onStep].emoji}
                </div>
                <h2 className="mt-6 text-[24px] font-black">{ONBOARD[onStep].title}</h2>
                <p className="mx-auto mt-3 max-w-[32ch] text-[14px] leading-7 text-white/70">
                  {ONBOARD[onStep].sub}
                </p>
              </div>
              <div className="mt-8 flex gap-2">
                {ONBOARD.map((_, i) => (
                  <span
                    key={i}
                    className={cn("h-2 rounded-full transition-all", i === onStep ? "w-8 bg-gold-400" : "w-2 bg-white/20")}
                  />
                ))}
              </div>
            </div>
            <button
              onClick={() => (onStep < ONBOARD.length - 1 ? setOnStep(onStep + 1) : finishOnboarding())}
              className="w-full rounded-2xl bg-gold-400 py-4 text-[16px] font-black text-ink-950 shadow-app transition hover:bg-gold-300 active:scale-[0.99]"
            >
              {onStep < ONBOARD.length - 1 ? "التالي" : "ابدأ الاستكشاف 🧭"}
            </button>
            <p className="mt-3 text-center text-[11px] text-white/40">بلا حسابات · بياناتك على جهازك فقط</p>
          </div>
        )}
      </div>

      {/* زخرفة جانبية للشاشات الكبيرة */}
      <div className="hidden flex-1 items-center justify-center p-10 lg:flex">
        <div className="max-w-md text-center text-white">
          <div className="mx-auto flex h-28 w-28 items-center justify-center rounded-[32px] bg-white shadow-app">
            <LogoIcon size={92} />
          </div>
          <h1 className="mt-6 text-4xl font-black">السحاب Cloud GPS</h1>
          <p className="mt-3 text-lg leading-8 text-white/60">
            ملاحة عربية ذكية للعراق — ابحث بلهجتك، تنقّل بتوجيه صوتي، واعمل دون اتصال. خصوصية كاملة بلا حسابات.
          </p>
          <div className="mt-6 flex justify-center gap-2 text-[13px] font-bold text-white/50">
            <span className="rounded-full bg-white/10 px-4 py-2">🗺️ 18 محافظة</span>
            <span className="rounded-full bg-white/10 px-4 py-2">✨ بحث ذكي</span>
            <span className="rounded-full bg-white/10 px-4 py-2">🔒 بلا حساب</span>
          </div>
        </div>
      </div>
    </div>
  );
}
