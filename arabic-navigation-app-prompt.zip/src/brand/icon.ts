import logoArtwork from "../assets/cloud-gps-mark.svg?raw";

export interface IconSpec {
  bgId: string;
  blue: string;
  navy: string;
  accent: string;
  cloud: boolean;
  swoosh: boolean;
  diamond: boolean;
  radius: number;
  scale: number;
}

export const BGS: { id: string; label: string; base: string; grad: [string, string] | null }[] = [
  { id: "white", label: "أبيض", base: "#ffffff", grad: null },
  { id: "navy", label: "كحلي", base: "#032341", grad: null },
  { id: "blue", label: "أزرق", base: "#006BDF", grad: null },
  { id: "sand", label: "رملي", base: "#F5F0E4", grad: null },
  { id: "sky", label: "سحابي متدرج", base: "#032341", grad: ["#2B7DE0", "#032341"] },
];

export const DEFAULT_SPEC: IconSpec = {
  bgId: "white",
  blue: "#006BDF",
  navy: "#032341",
  accent: "#006BDF",
  cloud: true,
  swoosh: true,
  diamond: true,
  radius: 56,
  scale: 0.86,
};

function safeColor(value: string, fallback: string): string {
  return /^#[\da-f]{6}$/i.test(value) ? value : fallback;
}

function clamp(value: number, min: number, max: number, fallback: number): number {
  return Number.isFinite(value) ? Math.min(max, Math.max(min, value)) : fallback;
}

// The app, favicon and exports all use the same artwork. Uniform scaling keeps
// the pin upright; real cutouts reveal any background without painted patches.
export function buildIconSvg(spec: IconSpec = DEFAULT_SPEC): string {
  const bg = BGS.find((b) => b.id === spec.bgId) ?? BGS[0];
  const blue = safeColor(spec.blue, DEFAULT_SPEC.blue);
  const navy = safeColor(spec.navy, DEFAULT_SPEC.navy);
  const accent = safeColor(spec.accent, DEFAULT_SPEC.accent);
  const radius = clamp(spec.radius, 0, 72, DEFAULT_SPEC.radius);
  const scale = clamp(spec.scale, 0.7, 1.05, DEFAULT_SPEC.scale);
  const edge = 240 * scale;
  const inset = (240 - edge) / 2;

  let artwork = logoArtwork
    .replace(/<rect data-logo-background="true"[^>]*\/>/, "")
    .replace(/(<g data-logo-part="(cloud|road|pin|diamond)" fill=")[^"]*(")/g,
      (_match, prefix: string, part: string, suffix: string) => {
        const color = part === "diamond" ? accent : part === "cloud" ? blue : navy;
        return `${prefix}${color}${suffix}`;
      })
    .replace("<svg ", `<svg x="${inset}" y="${inset}" width="${edge}" height="${edge}" `);

  for (const [part, visible] of [["cloud", spec.cloud], ["road", spec.swoosh], ["diamond", spec.diamond]] as const) {
    if (!visible) {
      artwork = artwork.replace(`data-logo-part="${part}"`, `data-logo-part="${part}" display="none"`);
    }
  }

  const defs = bg.grad
    ? `<defs><linearGradient id="icon-bg" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0" stop-color="${bg.grad[0]}"/><stop offset="1" stop-color="${bg.grad[1]}"/></linearGradient></defs>`
    : "";

  return `<svg xmlns="http://www.w3.org/2000/svg" width="512" height="512" viewBox="0 0 240 240" preserveAspectRatio="xMidYMid meet">${defs}<rect width="240" height="240" rx="${radius}" fill="${bg.grad ? "url(#icon-bg)" : bg.base}"/>${artwork}</svg>`;
}