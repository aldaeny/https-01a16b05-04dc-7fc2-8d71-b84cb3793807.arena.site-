import { useMemo, useState } from "react";
import { Palette, Download, Image as ImageIcon, Globe, RotateCcw, Check, ShieldCheck, Cloud, Route, Diamond } from "lucide-react";
import { cn } from "../utils/cn";
import logoUrl from "../assets/cloud-gps-mark.svg?inline";
import { BGS, DEFAULT_SPEC, buildIconSvg, type IconSpec } from "../brand/icon";

export { buildIconSvg } from "../brand/icon";
export type { IconSpec } from "../brand/icon";

const PRESETS: { id: string; label: string; spec: Partial<IconSpec> }[] = [
  { id: "classic", label: "كلاسيكي", spec: DEFAULT_SPEC },
  { id: "night", label: "ليلي", spec: { bgId: "navy", blue: "#2B7DE0", navy: "#ffffff", accent: "#F5B301" } },
  { id: "sky", label: "سحابي", spec: { bgId: "sky", blue: "#ffffff", navy: "#032341", accent: "#F5B301" } },
  { id: "gold", label: "رملي ذهبي", spec: { bgId: "sand", blue: "#006BDF", navy: "#032341", accent: "#D99A00" } },
  { id: "deepblue", label: "أزرق داكن", spec: { bgId: "blue", blue: "#ffffff", navy: "#032341", accent: "#F5B301" } },
];

const BLUE_OPTS = ["#006BDF", "#2B7DE0", "#0EA5E9", "#0D9488", "#6D28D9"];
const DARK_OPTS = ["#032341", "#0F172A", "#1E3A5F", "#ffffff", "#006BDF"];
const ACCENT_OPTS = ["#006BDF", "#F5B301", "#0EA5E9", "#10B981", "#EF4444"];

function ColorRow({
  label, value, options, onChange,
}: { label: string; value: string; options: string[]; onChange: (v: string) => void }) {
  return (
    <div className="mt-3">
      <p className="mb-1.5 text-[11px] font-black text-slate-600">{label}</p>
      <div className="flex items-center gap-1.5">
        {options.map((o) => (
          <button
            key={o}
            onClick={() => onChange(o)}
            aria-label={o}
            className={cn(
              "h-8 w-8 rounded-lg ring-1 ring-black/10 transition active:scale-90",
              value.toLowerCase() === o.toLowerCase() && "scale-110 ring-2 ring-ink-900 ring-offset-2"
            )}
            style={{ background: o }}
          />
        ))}
        <label
          title="لون مخصص"
          className="relative h-8 w-8 cursor-pointer overflow-hidden rounded-lg ring-1 ring-black/10"
          style={{
            background: `conic-gradient(#ef4444,#f5b301,#10b981,#0ea5e9,#8b5cf6,#ef4444)`,
          }}
        >
          <input
            type="color"
            aria-label={`${label} مخصص`}
            value={/^#[0-9a-fA-F]{6}$/.test(value) ? value : "#000000"}
            onChange={(e) => onChange(e.target.value)}
            className="absolute inset-0 h-full w-full cursor-pointer opacity-0"
          />
        </label>
      </div>
    </div>
  );
}

export default function IconStudio() {
  const [spec, setSpec] = useState<IconSpec>(DEFAULT_SPEC);
  const [msg, setMsg] = useState<string | null>(null);
  const [faviconSet, setFaviconSet] = useState(false);

  const svg = useMemo(() => buildIconSvg(spec), [spec]);
  const dataUri = useMemo(
    () => "data:image/svg+xml;charset=utf-8," + encodeURIComponent(svg),
    [svg]
  );

  const presetUris = useMemo(
    () =>
      Object.fromEntries(
        PRESETS.map((p) => [
          p.id,
          "data:image/svg+xml;charset=utf-8," + encodeURIComponent(buildIconSvg({ ...DEFAULT_SPEC, ...p.spec })),
        ])
      ),
    []
  );

  const set = (p: Partial<IconSpec>) => {
    setSpec((s) => ({ ...s, ...p }));
    setFaviconSet(false);
  };
  const flash = (m: string) => {
    setMsg(m);
    window.setTimeout(() => setMsg(null), 2800);
  };
  const dl = (name: string, url: string) => {
    const a = document.createElement("a");
    a.href = url;
    a.download = name;
    document.body.appendChild(a);
    a.click();
    a.remove();
  };

  const dlSvg = () => {
    dl("alsahab-cloud-gps-icon.svg", dataUri);
    flash("بدأ تنزيل الأيقونة بصيغة SVG");
  };
  const dlPng = () => {
    const img = new Image();
    img.onload = () => {
      const c = document.createElement("canvas");
      c.width = 512;
      c.height = 512;
      const ctx = c.getContext("2d");
      if (!ctx) { flash("تعذّر إنشاء PNG"); return; }
      ctx.drawImage(img, 0, 0, 512, 512);
      dl("alsahab-cloud-gps-icon-512.png", c.toDataURL("image/png"));
      flash("بدأ تنزيل PNG بحجم 512×512");
    };
    img.onerror = () => flash("تعذّر إنشاء PNG");
    img.src = dataUri;
  };
  const setFavicon = () => {
    let link = document.querySelector<HTMLLinkElement>('link[rel="icon"]');
    if (!link) {
      link = document.createElement("link");
      link.rel = "icon";
      document.head.appendChild(link);
    }
    link.type = "image/svg+xml";
    link.href = dataUri;
    setFaviconSet(true);
    flash("تم تعيين أيقونة المتصفح");
  };
  const reset = () => {
    setSpec(DEFAULT_SPEC);
    setFaviconSet(false);
    const link = document.querySelector<HTMLLinkElement>('link[rel="icon"]');
    if (link) link.href = logoUrl;
    flash("تمت استعادة الشعار الأساسي");
  };

  return (
    <div className="overflow-hidden rounded-2xl bg-white shadow-card ring-1 ring-slate-900/5">
      {/* الترويسة */}
      <div className="flex items-center gap-3 border-b border-dashed border-slate-100 p-4">
        <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br from-[#1568CC] to-[#0F2444] text-white shadow-card">
          <Palette size={20} />
        </span>
        <div>
          <p className="text-[14px] font-black text-slate-800">استوديو أيقونة التطبيق</p>
          <p className="text-[11px] text-slate-500">خصّص الألوان والخلفية مع الحفاظ على نسب الشعار</p>
        </div>
      </div>

      <div className="p-4">
        {/* المعاينة الحية */}
        <div className="flex flex-col items-center rounded-3xl bg-slate-50 p-5 ring-1 ring-slate-900/5">
          <img
            src={dataUri}
            alt="معاينة الأيقونة"
            width={148}
            height={148}
            className="aspect-square shrink-0 object-contain drop-shadow-xl"
          />
          <div className="mt-4 flex max-w-full flex-wrap items-end justify-center gap-4">
            {[84, 56, 40, 28].map((s) => (
              <div key={s} className="flex flex-col items-center gap-1.5">
                <img src={dataUri} width={s} height={s} alt="" className="aspect-square shrink-0 object-contain" />
                <span className="text-[10px] font-bold text-slate-400">{s} بكسل</span>
              </div>
            ))}
          </div>
        </div>

        {/* قوالب جاهزة */}
        <p className="mb-1.5 mt-4 text-[11px] font-black text-slate-600">قوالب جاهزة</p>
        <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
          {PRESETS.map((p) => (
            <button
              key={p.id}
              onClick={() => { setSpec({ ...DEFAULT_SPEC, ...p.spec }); setFaviconSet(false); }}
              className="flex shrink-0 items-center gap-2 rounded-full bg-slate-50 px-3 py-1.5 ring-1 ring-slate-200 transition hover:ring-ink-900/30 active:scale-95"
            >
              <img src={presetUris[p.id]} alt="" className="h-6 w-6 shrink-0 rounded-md object-contain ring-1 ring-black/5" />
              <span className="text-[12px] font-black text-slate-700">{p.label}</span>
            </button>
          ))}
        </div>

        {/* الخلفية */}
        <p className="mb-1.5 mt-4 text-[11px] font-black text-slate-600">خلفية الأيقونة</p>
        <div className="flex gap-2">
          {BGS.map((b) => (
            <button
              key={b.id}
              onClick={() => set({ bgId: b.id })}
              title={b.label}
              aria-label={b.label}
              className={cn(
                "h-10 w-10 rounded-xl ring-1 ring-black/10 transition active:scale-90",
                spec.bgId === b.id && "scale-110 ring-2 ring-ink-900 ring-offset-2"
              )}
              style={{ background: b.grad ? `linear-gradient(135deg, ${b.grad[0]}, ${b.grad[1]})` : b.base }}
            />
          ))}
        </div>

        {/* الألوان */}
        <ColorRow label="لون السحابة" value={spec.blue} options={BLUE_OPTS} onChange={(v) => set({ blue: v })} />
        <ColorRow label="لون الدبوس والطريق" value={spec.navy} options={DARK_OPTS} onChange={(v) => set({ navy: v })} />
        <ColorRow label="لون المربع المائل" value={spec.accent} options={ACCENT_OPTS} onChange={(v) => set({ accent: v })} />

        {/* العناصر */}
        <p className="mb-1.5 mt-4 text-[11px] font-black text-slate-600">العناصر</p>
        <div className="grid grid-cols-3 gap-1.5">
          {(
            [
              ["cloud", "السحابة", Cloud],
              ["swoosh", "الطريق", Route],
              ["diamond", "المربع", Diamond],
            ] as const
          ).map(([k, lbl, Icon]) => (
            <button
              key={k}
              aria-pressed={spec[k]}
              onClick={() => set({ [k]: !spec[k] } as Partial<IconSpec>)}
              className={cn(
                "flex items-center justify-center gap-1.5 rounded-xl py-2.5 text-[12px] font-black transition active:scale-95",
                spec[k] ? "bg-ink-900 text-white shadow-card" : "bg-slate-100 text-slate-400"
              )}
            >
              <Icon size={14} /> {lbl}
            </button>
          ))}
        </div>

        {/* الضبط */}
        <div className="mt-4 grid grid-cols-2 gap-4">
          <div>
            <div className="mb-1 flex items-center justify-between">
              <p className="text-[11px] font-black text-slate-600">استدارة الزوايا</p>
              <span className="text-[11px] font-black text-slate-400">{spec.radius}</span>
            </div>
            <input
              type="range"
              aria-label="استدارة الزوايا"
              min={0}
              max={72}
              value={spec.radius}
              onChange={(e) => set({ radius: Number(e.target.value) })}
              className="w-full accent-ink-900"
            />
          </div>
          <div>
            <div className="mb-1 flex items-center justify-between">
              <p className="text-[11px] font-black text-slate-600">حجم الرسم</p>
              <span className="text-[11px] font-black text-slate-400">{Math.round(spec.scale * 100)}%</span>
            </div>
            <input
              type="range"
              aria-label="حجم الرسم"
              min={70}
              max={105}
              value={Math.round(spec.scale * 100)}
              onChange={(e) => set({ scale: Number(e.target.value) / 100 })}
              className="w-full accent-ink-900"
            />
          </div>
        </div>

        {/* الأزرار */}
        <div className="mt-5 grid grid-cols-2 gap-2">
          <button
            onClick={dlSvg}
            className="flex items-center justify-center gap-2 rounded-2xl bg-gradient-to-l from-[#1568CC] to-[#0F2444] py-3 text-[13px] font-black text-white shadow-card transition active:scale-[0.98]"
          >
            <Download size={16} /> تنزيل SVG
          </button>
          <button
            onClick={dlPng}
            className="flex items-center justify-center gap-2 rounded-2xl bg-ink-900 py-3 text-[13px] font-black text-white shadow-card transition active:scale-[0.98]"
          >
            <ImageIcon size={16} /> تنزيل PNG 512
          </button>
          <button
            onClick={setFavicon}
            className={cn(
              "flex items-center justify-center gap-2 rounded-2xl py-3 text-[13px] font-black transition active:scale-[0.98]",
              faviconSet
                ? "bg-emerald-500 text-white shadow-card"
                : "bg-gold-400 text-ink-950 shadow-card hover:bg-gold-300"
            )}
          >
            {faviconSet ? <Check size={16} /> : <Globe size={16} />}
            {faviconSet ? "تم التعيين" : "أيقونة المتصفح"}
          </button>
          <button
            onClick={reset}
            className="flex items-center justify-center gap-2 rounded-2xl bg-red-50 py-3 text-[13px] font-black text-red-600 ring-1 ring-red-100 transition hover:bg-red-100 active:scale-[0.98]"
          >
            <RotateCcw size={16} /> استعادة الشعار
          </button>
        </div>

        {msg && (
          <p role="status" className="mt-3 animate-fade-up text-center text-[12px] font-black text-emerald-600">{msg}</p>
        )}

        <p className="mt-3 flex items-center justify-center gap-1 text-center text-[11px] font-bold text-slate-400">
          <ShieldCheck size={12} /> تُولَّد وتُنزَّل الأيقونة على جهازك فقط، ولا تُرفع لأي خادم
        </p>
      </div>
    </div>
  );
}
