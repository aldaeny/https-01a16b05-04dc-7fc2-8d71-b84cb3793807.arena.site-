import { cn } from "../utils/cn";
import logoUrl from "../assets/cloud-gps-mark.svg?inline";

export function LogoIcon({ size = 64, className }: { size?: number; className?: string }) {
  return (
    <img
      src={logoUrl}
      width={size}
      height={size}
      alt="شعار السحاب Cloud GPS"
      draggable={false}
      className={cn("block shrink-0 object-contain", className)}
      style={{ width: size, height: size, aspectRatio: "1 / 1", flexShrink: 0 }}
    />
  );
}

export function Logo({
  size = 96,
  light = false,
  showWordmark = true,
  className,
}: {
  size?: number;
  light?: boolean;
  showWordmark?: boolean;
  className?: string;
}) {
  return (
    <div className={cn("flex flex-col items-center", className)}>
      <div
        className="flex items-center justify-center rounded-[26%] bg-white shadow-card"
        style={{ width: size, height: size }}
      >
        <LogoIcon size={size * 0.8} />
      </div>
      {showWordmark && (
        <div className="mt-3 leading-none">
          <span
            className="block text-[26px] font-black tracking-tight"
            style={{ color: light ? "#ffffff" : "#032341" }}
          >
            السحاب
          </span>
          <span
            dir="ltr"
            className="mt-1.5 block text-[14px] font-bold tracking-[0.16em]"
            style={{ color: light ? "rgba(255,255,255,0.72)" : "#4a5f7a" }}
          >
            cloud <span style={{ color: "#006BDF" }}>gps</span>
          </span>
        </div>
      )}
    </div>
  );
}
