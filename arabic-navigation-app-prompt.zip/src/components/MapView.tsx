import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Minus, Plus, LocateFixed, Layers } from "lucide-react";
import { cn } from "../utils/cn";
import { latToY, lonToX, xToLon, yToLat } from "../utils/geo";
import type { Place } from "../types";
import { CATEGORY_ICON } from "./ui";

interface MapViewProps {
  center: [number, number]; // [lat, lon]
  zoom: number;
  onCenterChange?: (c: [number, number]) => void;
  onZoomChange?: (z: number) => void;
  markers?: Place[];
  selectedId?: string | null;
  onMarkerClick?: (p: Place) => void;
  routeGeom?: [number, number][] | null; // [lon,lat]
  userLocation?: [number, number] | null;
  navPosition?: [number, number] | null; // [lat,lon] أثناء الملاحة
  dark?: boolean;
  online?: boolean;
  className?: string;
  interactive?: boolean;
}

const TILE = 256;

export default function MapView({
  center, zoom, onCenterChange, onZoomChange,
  markers = [], selectedId, onMarkerClick,
  routeGeom, userLocation, navPosition, dark, online = true,
  className, interactive = true,
}: MapViewProps) {
  const boxRef = useRef<HTMLDivElement>(null);
  const [size, setSize] = useState({ w: 0, h: 0 });
  const [tilesOk, setTilesOk] = useState(true);
  const drag = useRef<{ x: number; y: number; lat: number; lon: number } | null>(null);

  useEffect(() => {
    const el = boxRef.current;
    if (!el) return;
    const ro = new ResizeObserver(() => {
      setSize({ w: el.clientWidth, h: el.clientHeight });
    });
    ro.observe(el);
    setSize({ w: el.clientWidth, h: el.clientHeight });
    return () => ro.disconnect();
  }, []);

  useEffect(() => { setTilesOk(true); }, [dark]);

  const [clat, clon] = center;
  const cz = Math.max(4, Math.min(18, Math.round(zoom)));

  // إسقاط: pixel بالنسبة لمركز الشاشة
  const project = useCallback((lat: number, lon: number) => {
    const scale = TILE * Math.pow(2, cz);
    const cx = lonToX(clon, cz) * TILE;
    const cy = latToY(clat, cz) * TILE;
    const x = lonToX(lon, cz) * TILE - cx;
    const y = latToY(lat, cz) * TILE - cy;
    void scale;
    return { x: size.w / 2 + x, y: size.h / 2 + y };
  }, [clat, clon, cz, size]);

  // بلاطات OSM حول المركز
  const tiles = useMemo(() => {
    if (!online || size.w === 0) return [];
    const tx = lonToX(clon, cz);
    const ty = latToY(clat, cz);
    const halfX = size.w / 2 / TILE + 1;
    const halfY = size.h / 2 / TILE + 1;
    const list: { x: number; y: number; left: number; top: number }[] = [];
    for (let dx = -Math.ceil(halfX); dx <= Math.ceil(halfX); dx++) {
      for (let dy = -Math.ceil(halfY); dy <= Math.ceil(halfY); dy++) {
        const x = Math.floor(tx + dx);
        const y = Math.floor(ty + dy);
        const max = Math.pow(2, cz);
        if (y < 0 || y >= max) continue;
        const xx = ((x % max) + max) % max;
        const left = size.w / 2 + (x - tx) * TILE;
        const top = size.h / 2 + (y - ty) * TILE;
        list.push({ x: xx, y, left, top });
      }
    }
    return list;
  }, [clon, clat, cz, size, online]);

  const tileUrl = (x: number, y: number) =>
    dark
      ? `https://basemaps.cartocdn.com/dark_all/${cz}/${x}/${y}.png`
      : `https://tile.openstreetmap.org/${cz}/${x}/${y}.png`;

  // سحب للتحريك
  const onPointerDown = (e: React.PointerEvent) => {
    if (!interactive) return;
    (e.target as HTMLElement).setPointerCapture?.(e.pointerId);
    drag.current = { x: e.clientX, y: e.clientY, lat: clat, lon: clon };
  };
  const onPointerMove = (e: React.PointerEvent) => {
    if (!drag.current || !interactive) return;
    const dx = e.clientX - drag.current.x;
    const dy = e.clientY - drag.current.y;
    if (Math.abs(dx) + Math.abs(dy) < 2) return;
    const cx = lonToX(drag.current.lon, cz) - dx / TILE;
    const cy = latToY(drag.current.lat, cz) - dy / TILE;
    onCenterChange?.([yToLat(cy, cz), xToLon(cx, cz)]);
  };
  const onPointerUp = () => { drag.current = null; };
  const onWheel = (e: React.WheelEvent) => {
    if (!interactive) return;
    e.preventDefault?.();
    const d = e.deltaY > 0 ? -1 : 1;
    onZoomChange?.(Math.max(5, Math.min(18, cz + d)));
  };

  const routePath = useMemo(() => {
    if (!routeGeom || routeGeom.length < 2 || size.w === 0) return "";
    return routeGeom.map(([lon, lat], i) => {
      const p = project(lat, lon);
      return `${i === 0 ? "M" : "L"}${p.x.toFixed(1)},${p.y.toFixed(1)}`;
    }).join(" ");
  }, [routeGeom, project, size]);

  const [showTiles, setShowTiles] = useState(true);

  return (
    <div
      ref={boxRef}
      onPointerDown={onPointerDown}
      onPointerMove={onPointerMove}
      onPointerUp={onPointerUp}
      onPointerLeave={onPointerUp}
      onWheel={onWheel}
      className={cn(
        "relative select-none overflow-hidden",
        dark ? "bg-[#0d1b1a]" : "bg-[#eef3ef]",
        interactive ? "cursor-grab active:cursor-grabbing" : "",
        className
      )}
      style={{ touchAction: interactive ? "none" : "auto" }}
    >
      {/* خلفية شبكية عند غياب البلاطات */}
      <div className={cn("absolute inset-0", dark ? "map-grid-bg-dark" : "map-grid-bg")} />

      {/* طرق تجميلية خلفية (زخرفية عند عدم الاتصال) */}
      {!online && <DecorRoads dark={dark} />}

      {/* بلاطات OSM الحية */}
      {online && showTiles && tilesOk && tiles.map((t) => (
        <img
          key={`${t.x}-${t.y}-${cz}`}
          src={tileUrl(t.x, t.y)}
          alt=""
          draggable={false}
          onError={() => setTilesOk(false)}
          className="pointer-events-none absolute"
          style={{ left: t.left, top: t.top, width: TILE, height: TILE, opacity: dark ? 0.92 : 1 }}
          loading="lazy"
        />
      ))}

      {/* تظليل خفيف لدمج البلاطات مع الهوية */}
      <div className={cn("pointer-events-none absolute inset-0", dark ? "bg-ink-950/10" : "bg-primary-900/[0.04]")} />

      {/* المسار */}
      {routePath && (
        <svg className="pointer-events-none absolute inset-0 h-full w-full">
          <path d={routePath} fill="none" stroke={dark ? "#0e2a27" : "#ffffff"} strokeWidth={11} strokeLinecap="round" strokeLinejoin="round" opacity={0.9} />
          <path d={routePath} fill="none" stroke="#0284c7" strokeWidth={6} strokeLinecap="round" strokeLinejoin="round" />
          <path d={routePath} fill="none" stroke="#7dd3fc" strokeWidth={2.5} strokeLinecap="round" className="route-dash" opacity={0.9} />
        </svg>
      )}

      {/* العلامات */}
      {markers.map((m) => {
        const p = project(m.lat, m.lon);
        if (p.x < -40 || p.y < -40 || p.x > size.w + 40 || p.y > size.h + 40) return null;
        const sel = m.id === selectedId;
        return (
          <button
            key={m.id}
            onClick={(e) => { e.stopPropagation(); onMarkerClick?.(m); }}
            className="absolute z-10 -translate-x-1/2 -translate-y-full transition-transform hover:scale-110"
            style={{ left: p.x, top: p.y }}
          >
            <div className={cn(
              "flex h-10 w-10 items-center justify-center rounded-full text-lg shadow-app ring-2 transition-all",
              sel ? "scale-125 bg-gold-400 ring-white" : "bg-white ring-primary-600/30"
            )}>
              {CATEGORY_ICON[m.category]}
            </div>
            <div className={cn("mx-auto h-2.5 w-2.5 rotate-45 -mt-1", sel ? "bg-gold-400" : "bg-white")} style={{ boxShadow: "0 2px 6px rgb(0 0 0/.3)" }} />
            {sel && (
              <div className="absolute left-1/2 top-full mt-1 w-max max-w-[180px] -translate-x-1/2 truncate rounded-lg bg-ink-900 px-2.5 py-1 text-[11px] font-bold text-white shadow-app">
                {m.name}
              </div>
            )}
          </button>
        );
      })}

      {/* موقع المستخدم */}
      {userLocation && !navPosition && (() => {
        const p = project(userLocation[0], userLocation[1]);
        return (
          <div className="pointer-events-none absolute z-20 -translate-x-1/2 -translate-y-1/2" style={{ left: p.x, top: p.y }}>
            <div className="absolute inset-0 -m-3 animate-pulse-ring rounded-full bg-sky-400/60" />
            <div className="relative flex h-6 w-6 items-center justify-center rounded-full bg-sky-500 ring-4 ring-white shadow-app">
              <div className="h-2 w-2 rounded-full bg-white" />
            </div>
          </div>
        );
      })()}

      {/* مؤشر الملاحة */}
      {navPosition && (() => {
        const p = project(navPosition[0], navPosition[1]);
        return (
          <div className="pointer-events-none absolute z-20 -translate-x-1/2 -translate-y-1/2" style={{ left: p.x, top: p.y }}>
            <div className="flex h-11 w-11 items-center justify-center rounded-full bg-ink-900 shadow-app ring-4 ring-gold-400">
              <span className="text-xl">🧭</span>
            </div>
          </div>
        );
      })()}

      {/* أدوات التحكم */}
      {interactive && (
        <div className="absolute left-3 top-1/2 z-30 flex -translate-y-1/2 flex-col gap-2">
          <div className="flex flex-col overflow-hidden rounded-2xl bg-white shadow-app ring-1 ring-slate-900/10">
            <button onClick={() => onZoomChange?.(Math.min(18, cz + 1))} className="p-2.5 text-slate-700 transition hover:bg-slate-50 active:bg-slate-100" aria-label="تكبير">
              <Plus size={18} />
            </button>
            <div className="h-px bg-slate-100" />
            <button onClick={() => onZoomChange?.(Math.max(5, cz - 1))} className="p-2.5 text-slate-700 transition hover:bg-slate-50 active:bg-slate-100" aria-label="تصغير">
              <Minus size={18} />
            </button>
          </div>
          <button
            onClick={() => setShowTiles((v) => !v)}
            className={cn("rounded-2xl p-2.5 shadow-app ring-1 transition", showTiles ? "bg-ink-900 text-white ring-ink-900" : "bg-white text-slate-500 ring-slate-900/10")}
            aria-label="الطبقات"
          >
            <Layers size={18} />
          </button>
        </div>
      )}

      {/* نسبة الحقوق */}
      <div className={cn("leaflet-attrib absolute bottom-1.5 left-2 z-30 rounded-md px-1.5 py-0.5", dark ? "bg-black/50 text-white/70" : "bg-white/80 text-slate-500")}>
        © OpenStreetMap · السحاب Cloud GPS
      </div>

      {/* مؤشر عدم الاتصال على الخريطة */}
      {!online && (
        <div className="absolute right-3 top-3 z-30 flex items-center gap-1.5 rounded-full bg-amber-400 px-3 py-1.5 text-[11px] font-black text-ink-950 shadow-app">
          <span className="h-2 w-2 animate-pulse rounded-full bg-ink-950" />
          خريطة تقريبية · دون اتصال
        </div>
      )}
    </div>
  );
}

function DecorRoads({ dark }: { dark?: boolean }) {
  const stroke = dark ? "rgb(255 255 255 / .08)" : "rgb(11 59 54 / .10)";
  const stroke2 = dark ? "rgb(245 179 1 / .25)" : "rgb(245 179 1 / .5)";
  return (
    <svg className="pointer-events-none absolute inset-0 h-full w-full opacity-80" preserveAspectRatio="none" viewBox="0 0 400 600">
      <path d="M-20,120 C120,100 180,200 420,160" stroke={stroke} strokeWidth="14" fill="none" />
      <path d="M-20,120 C120,100 180,200 420,160" stroke={stroke2} strokeWidth="2" strokeDasharray="8 6" fill="none" />
      <path d="M60,-20 C80,200 40,400 100,620" stroke={stroke} strokeWidth="10" fill="none" />
      <path d="M300,-20 C280,180 340,380 300,620" stroke={stroke} strokeWidth="10" fill="none" />
      <path d="M-20,420 C140,400 260,460 420,400" stroke={stroke} strokeWidth="12" fill="none" />
      <circle cx="200" cy="290" r="46" stroke={stroke} strokeWidth="8" fill="none" />
      <circle cx="200" cy="290" r="46" stroke={stroke2} strokeWidth="1.5" strokeDasharray="6 5" fill="none" />
    </svg>
  );
}

// زر الموقع العائم (يُستخدم في الصفحة الرئيسية)
export function LocateButton({ onClick, loading }: { onClick: () => void; loading?: boolean }) {
  return (
    <button
      onClick={onClick}
      className="flex h-12 w-12 items-center justify-center rounded-2xl bg-white text-primary-700 shadow-app ring-1 ring-slate-900/10 transition hover:scale-105 active:scale-95"
      aria-label="موقعي الحالي"
    >
      <LocateFixed size={20} className={loading ? "animate-spin" : ""} />
    </button>
  );
}
