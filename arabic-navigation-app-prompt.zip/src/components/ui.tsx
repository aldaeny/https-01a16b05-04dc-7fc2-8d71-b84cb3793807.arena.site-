import { type ReactNode } from "react";
import { Star, MapPin } from "lucide-react";
import { cn } from "../utils/cn";
import type { Place, PlaceCategory } from "../types";
import { CATEGORY_AR, govName } from "../data/iraq";
import { formatDistance } from "../utils/geo";

export const CATEGORY_ICON: Record<PlaceCategory, string> = {
  landmark: "🏛️", mosque: "🕌", restaurant: "🍖", cafe: "☕",
  mall: "🛍️", hospital: "🏥", pharmacy: "💊", hotel: "🏨",
  fuel: "⛽", bank: "🏦", university: "🎓", park: "🌳",
  government: "🏢", station: "✈️", market: "🧺",
};

export function Stars({ rating, size = 12 }: { rating?: number; size?: number }) {
  if (!rating) return null;
  return (
    <span className="inline-flex items-center gap-1 rounded-full bg-amber-50 px-2 py-0.5 text-[11px] font-bold text-amber-700 ring-1 ring-amber-200">
      <Star size={size} className="fill-amber-400 text-amber-400" />
      {rating.toFixed(1)}
    </span>
  );
}

export function CategoryPill({ cat }: { cat: PlaceCategory }) {
  return (
    <span className="inline-flex items-center gap-1 rounded-full bg-primary-50 px-2 py-0.5 text-[11px] font-bold text-primary-700 ring-1 ring-primary-100">
      <span>{CATEGORY_ICON[cat]}</span> {CATEGORY_AR[cat]}
    </span>
  );
}

export function PlaceCard({
  place, distanceM, onOpen, onRoute, trailing, compact,
}: {
  place: Place;
  distanceM?: number;
  onOpen: () => void;
  onRoute?: () => void;
  trailing?: ReactNode;
  compact?: boolean;
}) {
  return (
    <div
      onClick={onOpen}
      className={cn(
        "group cursor-pointer rounded-2xl bg-white p-3 shadow-card ring-1 ring-slate-900/5 transition-all hover:-translate-y-0.5 hover:shadow-app active:translate-y-0",
        compact && "p-2.5"
      )}
    >
      <div className="flex items-start gap-3">
        <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-primary-600 to-ink-900 text-2xl shadow-card">
          {CATEGORY_ICON[place.category]}
        </div>
        <div className="min-w-0 flex-1">
          <div className="flex items-start justify-between gap-2">
            <h3 className="truncate text-[15px] font-extrabold text-slate-900">{place.name}</h3>
            {distanceM !== undefined && (
              <span className="shrink-0 rounded-full bg-slate-100 px-2 py-0.5 text-[11px] font-bold text-slate-600">
                {formatDistance(distanceM)}
              </span>
            )}
          </div>
          <p className="mt-0.5 flex items-center gap-1 truncate text-xs text-slate-500">
            <MapPin size={11} className="shrink-0" />
            {place.address} · {govName(place.governorate)}
          </p>
          <div className="mt-1.5 flex flex-wrap items-center gap-1.5">
            <CategoryPill cat={place.category} />
            <Stars rating={place.rating} />
            {place.hours && (
              <span className="rounded-full bg-emerald-50 px-2 py-0.5 text-[11px] font-bold text-emerald-700 ring-1 ring-emerald-100">
                {place.hours}
              </span>
            )}
            {place.source !== "local" && (
              <span className="rounded-full bg-sky-50 px-2 py-0.5 text-[11px] font-bold text-sky-700 ring-1 ring-sky-100">
                {place.source === "smart" ? "✨ ذكي" : "🌐 حي"}
              </span>
            )}
          </div>
        </div>
      </div>
      {(onRoute || trailing) && (
        <div className="mt-2.5 flex items-center gap-2 border-t border-dashed border-slate-100 pt-2.5" onClick={(e) => e.stopPropagation()}>
          {onRoute && (
            <button
              onClick={onRoute}
              className="flex-1 rounded-xl bg-ink-900 py-2 text-[13px] font-extrabold text-white transition hover:bg-primary-600 active:scale-[0.98]"
            >
              🧭 الاتجاهات
            </button>
          )}
          {trailing}
        </div>
      )}
    </div>
  );
}

export function SectionTitle({ title, sub, action }: { title: string; sub?: string; action?: ReactNode }) {
  return (
    <div className="mb-3 flex items-end justify-between">
      <div>
        <h2 className="text-[17px] font-black text-slate-900">{title}</h2>
        {sub && <p className="mt-0.5 text-xs text-slate-500">{sub}</p>}
      </div>
      {action}
    </div>
  );
}

export function EmptyState({ emoji, title, sub, action }: { emoji: string; title: string; sub?: string; action?: ReactNode }) {
  return (
    <div className="flex flex-col items-center rounded-3xl bg-white/70 px-6 py-10 text-center ring-1 ring-slate-900/5">
      <div className="flex h-16 w-16 items-center justify-center rounded-3xl bg-sand-100 text-3xl">{emoji}</div>
      <h3 className="mt-3 text-[15px] font-black text-slate-800">{title}</h3>
      {sub && <p className="mt-1 max-w-[26ch] text-xs leading-6 text-slate-500">{sub}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

export function Chip({ active, children, onClick }: { active?: boolean; children: ReactNode; onClick?: () => void }) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "shrink-0 rounded-full px-3.5 py-2 text-[13px] font-bold transition-all active:scale-95",
        active
          ? "bg-ink-900 text-white shadow-card"
          : "bg-white text-slate-600 ring-1 ring-slate-200 hover:ring-slate-300"
      )}
    >
      {children}
    </button>
  );
}
