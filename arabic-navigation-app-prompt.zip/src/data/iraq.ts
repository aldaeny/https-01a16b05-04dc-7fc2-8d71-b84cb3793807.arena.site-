import type { Governorate, Place, PlaceCategory } from "../types";

export const GOVERNORATES: Governorate[] = [
  { id: "baghdad", name: "بغداد", nameEn: "Baghdad", lat: 33.3152, lon: 44.3661, zoom: 12 },
  { id: "basra", name: "البصرة", nameEn: "Basra", lat: 30.5085, lon: 47.7804, zoom: 12 },
  { id: "nineveh", name: "نينوى · الموصل", nameEn: "Mosul", lat: 36.335, lon: 43.1189, zoom: 12 },
  { id: "erbil", name: "أربيل", nameEn: "Erbil", lat: 36.1911, lon: 44.0094, zoom: 12 },
  { id: "sulaymaniyah", name: "السليمانية", nameEn: "Sulaymaniyah", lat: 35.5611, lon: 45.4347, zoom: 12 },
  { id: "duhok", name: "دهوك", nameEn: "Duhok", lat: 36.8671, lon: 42.9884, zoom: 12 },
  { id: "kirkuk", name: "كركوك", nameEn: "Kirkuk", lat: 35.4681, lon: 44.3922, zoom: 12 },
  { id: "salahuddin", name: "صلاح الدين · تكريت", nameEn: "Tikrit", lat: 34.6104, lon: 43.6811, zoom: 11 },
  { id: "anbar", name: "الأنبار · الرمادي", nameEn: "Ramadi", lat: 33.4256, lon: 43.3009, zoom: 11 },
  { id: "diyala", name: "ديالى · بعقوبة", nameEn: "Baqubah", lat: 33.745, lon: 44.6369, zoom: 11 },
  { id: "wasit", name: "واسط · الكوت", nameEn: "Kut", lat: 32.5088, lon: 45.8199, zoom: 11 },
  { id: "babil", name: "بابل · الحلة", nameEn: "Hillah", lat: 32.4725, lon: 44.4311, zoom: 11 },
  { id: "karbala", name: "كربلاء", nameEn: "Karbala", lat: 32.616, lon: 44.0249, zoom: 12 },
  { id: "najaf", name: "النجف", nameEn: "Najaf", lat: 32.0, lon: 44.33, zoom: 12 },
  { id: "dhiqar", name: "ذي قار · الناصرية", nameEn: "Nasiriyah", lat: 31.0465, lon: 46.2572, zoom: 11 },
  { id: "maysan", name: "ميسان · العمارة", nameEn: "Amarah", lat: 31.8357, lon: 47.1448, zoom: 11 },
  { id: "muthanna", name: "المثنى · السماوة", nameEn: "Samawah", lat: 31.325, lon: 45.2808, zoom: 11 },
  { id: "qadisiyah", name: "القادسية · الديوانية", nameEn: "Diwaniyah", lat: 31.9892, lon: 45.2802, zoom: 11 },
];

export const govName = (id: string) =>
  GOVERNORATES.find((g) => g.id === id)?.name ?? id;

export const CATEGORY_AR: Record<PlaceCategory, string> = {
  landmark: "معالم",
  mosque: "مساجد ومراقد",
  restaurant: "مطاعم",
  cafe: "مقاهي",
  mall: "مولات وأسواق",
  hospital: "مستشفيات",
  pharmacy: "صيدليات",
  hotel: "فنادق",
  fuel: "محطات وقود",
  bank: "مصارف",
  university: "جامعات",
  park: "متنزهات",
  government: "دوائر حكومية",
  station: "محطات نقل",
  market: "أسواق شعبية",
};

// ─── قاعدة بيانات محلية غنية لعموم العراق ───
export const LOCAL_PLACES: Place[] = [
  // ===== بغداد =====
  { id: "bgd-001", name: "المنطقة الخضراء · بوابة التشريع", category: "government", governorate: "baghdad", address: "الكرخ، بغداد", lat: 33.313, lon: 44.3665, rating: 4.1, reviews: 890, tags: ["حكومي", "دوائر", "الكرخ"], description: "مدخل المنطقة الدولية وسط بغداد.", source: "local" },
  { id: "bgd-002", name: "مول المنصور", category: "mall", governorate: "baghdad", address: "المنصور، شارع الأميرات", lat: 33.3089, lon: 44.34, rating: 4.4, reviews: 12400, tags: ["تسوق", "مطاعم", "سينما", "المنصور"], hours: "10ص - 11م", description: "من أكبر مولات بغداد، تسوق وترفيه ومطاعم.", source: "local" },
  { id: "bgd-003", name: "مطعم الساعة · مشويات عراقية", category: "restaurant", governorate: "baghdad", address: "المنصور، شارع 14 رمضان", lat: 33.3115, lon: 44.3435, rating: 4.6, reviews: 3200, tags: ["مشويات", "كباب", "تكة", "عائلي", "المنصور"], hours: "12ظ - 12م", description: "مشويات عراقية أصيلة: كباب، تكة، معلاق.", source: "local" },
  { id: "bgd-004", name: "المتنبي · شارع الثقافة", category: "market", governorate: "baghdad", address: "الرصافة، القشلة", lat: 33.3387, lon: 44.3876, rating: 4.8, reviews: 9800, tags: ["كتب", "ثقافة", "تراث", "المتنبي"], description: "قلب بغداد الثقافي، مكتبات ومقاهي تراثية كل جمعة.", source: "local" },
  { id: "bgd-005", name: "مستشفى مدينة الطب", category: "hospital", governorate: "baghdad", address: "باب المعظم، الرصافة", lat: 33.3475, lon: 44.3808, rating: 3.9, reviews: 5600, phone: "07800000001", tags: ["طوارئ", "حكومي", "24 ساعة"], description: "أكبر مجمع طبي حكومي في العراق، طوارئ 24 ساعة.", source: "local" },
  { id: "bgd-006", name: "جامع الإمام الأعظم", category: "mosque", governorate: "baghdad", address: "الأعظمية", lat: 33.3716, lon: 44.3589, rating: 4.9, reviews: 4100, tags: ["ديني", "تراث", "الأعظمية"], description: "مرقد الإمام أبي حنيفة، معلم ديني وتاريخي.", source: "local" },
  { id: "bgd-007", name: "متنزه الزوراء", category: "park", governorate: "baghdad", address: "الكرخ", lat: 33.3136, lon: 44.3747, rating: 4.3, reviews: 15200, tags: ["عوائل", "ألعاب", "حديقة حيوان"], hours: "9ص - 10م", description: "أكبر متنزهات بغداد مع مدينة ألعاب وحديقة حيوان.", source: "local" },
  { id: "bgd-008", name: "مطار بغداد الدولي", category: "station", governorate: "baghdad", address: "طريق المطار", lat: 33.2625, lon: 44.2346, rating: 3.8, reviews: 8900, tags: ["سفر", "طيران", "تاكسي"], description: "البوابة الجوية الرئيسية للعاصمة.", source: "local" },
  { id: "bgd-009", name: "فندق الرشيد", category: "hotel", governorate: "baghdad", address: "المنطقة الخضراء", lat: 33.3165, lon: 44.3885, rating: 4.2, reviews: 2100, tags: ["5 نجوم", "رجال أعمال"], description: "فندق تاريخي عريق وسط بغداد.", source: "local" },
  { id: "bgd-010", name: "سوق الشورجة", category: "market", governorate: "baghdad", address: "الرصافة", lat: 33.3358, lon: 44.3926, rating: 4.2, reviews: 6700, tags: ["جملة", "رخيص", "شعبي"], description: "أشهر أسواق الجملة الشعبية في بغداد.", source: "local" },
  { id: "bgd-011", name: "مقهى الشابندر التراثي", category: "cafe", governorate: "baghdad", address: "شارع المتنبي", lat: 33.3392, lon: 44.3882, rating: 4.7, reviews: 2800, tags: ["تراث", "شاي", "ثقافة"], description: "مقهى بغدادي عريق منذ 1917.", source: "local" },
  { id: "bgd-012", name: "محطة وقود المنصور المركزية", category: "fuel", governorate: "baghdad", address: "المنصور، شارع النقابات", lat: 33.3055, lon: 44.3372, rating: 4.0, reviews: 1200, tags: ["بنزين", "محسن", "عادي"], hours: "24 ساعة", description: "وقود بنوعيه مع خدمة غسيل.", source: "local" },
  { id: "bgd-013", name: "الجامعة المستنصرية", category: "university", governorate: "baghdad", address: "شارع فلسطين", lat: 33.3334, lon: 44.4436, rating: 4.1, reviews: 3400, tags: ["تعليم", "حكومية"], description: "من أعرق الجامعات العراقية.", source: "local" },
  { id: "bgd-014", name: "صيدلية الشفاء الخافرة", category: "pharmacy", governorate: "baghdad", address: "الكرادة خارج", lat: 33.3011, lon: 44.4255, rating: 4.5, reviews: 890, tags: ["خافرة", "24 ساعة", "توصيل"], hours: "24 ساعة", description: "صيدلية خافرة مع توصيل.", source: "local" },
  { id: "bgd-015", name: "برج بغداد · المأمون", category: "landmark", governorate: "baghdad", address: "المأمون، الكرخ", lat: 33.3003, lon: 44.3518, rating: 4.0, reviews: 4500, tags: ["سياحة", "مطعم دوار", "إطلالة"], description: "برج الاتصالات والمطعم الدوار بإطلالة بانورامية.", source: "local" },

  // ===== البصرة =====
  { id: "bsr-001", name: "كورنيش البصرة · شط العرب", category: "park", governorate: "basra", address: "المعقل، شط العرب", lat: 30.52, lon: 47.81, rating: 4.6, reviews: 7200, tags: ["كورنيش", "عوائل", "غروب"], description: "أجمل متنفس في البصرة على ضفاف شط العرب.", source: "local" },
  { id: "bsr-002", name: "مطعم أسماك البصرة · مسكوف", category: "restaurant", governorate: "baghdad", address: "كورنيش شط العرب", lat: 30.5225, lon: 47.815, rating: 4.7, reviews: 4100, tags: ["مسكوف", "سمك", "شط العرب"], hours: "12ظ - 11م", description: "مسكوف على الحطب بإطلالة على الشط.", source: "local" },
  { id: "bsr-003", name: "مول بصرة تايمز سكوير", category: "mall", governorate: "basra", address: "شارع الوفود", lat: 30.4975, lon: 47.7826, rating: 4.3, reviews: 5600, tags: ["تسوق", "سينما"], hours: "10ص - 11م", description: "وجهة التسوق الأولى في البصرة.", source: "local" },
  { id: "bsr-004", name: "مستشفى البصرة التعليمي", category: "hospital", governorate: "basra", address: "المعقل", lat: 30.5268, lon: 47.7789, rating: 3.8, reviews: 2300, tags: ["طوارئ", "حكومي"], description: "مستشفى تعليمي رئيسي بطوارئ 24 ساعة.", source: "local" },
  { id: "bsr-005", name: "مطار البصرة الدولي", category: "station", governorate: "basra", address: "طريق المطار", lat: 30.5491, lon: 47.6621, rating: 3.9, reviews: 3100, tags: ["سفر", "طيران"], description: "مطار الجنوب الرئيسي.", source: "local" },

  // ===== الموصل =====
  { id: "msl-001", name: "جامع النوري الكبير والمنارة الحدباء", category: "mosque", governorate: "nineveh", address: "الموصل القديمة", lat: 36.3432, lon: 43.1269, rating: 4.9, reviews: 5200, tags: ["تراث", "تاريخي", "ديني"], description: "رمز الموصل التاريخي، المنارة الحدباء الشهيرة.", source: "local" },
  { id: "msl-002", name: "مول الموصل · المثنى", category: "mall", governorate: "nineveh", address: "حي المثنى", lat: 36.3512, lon: 43.1523, rating: 4.2, reviews: 3800, tags: ["تسوق", "مطاعم"], description: "أكبر مولات الموصل.", source: "local" },
  { id: "msl-003", name: "مطعم قصر الملوك · باجة وكباب", category: "restaurant", governorate: "nineveh", address: "الدوسة", lat: 36.3385, lon: 43.1456, rating: 4.5, reviews: 1900, tags: ["موصلي", "باجة", "كباب"], description: "أكلات موصلية أصيلة.", source: "local" },
  { id: "msl-004", name: "غابات الموصل السياحية", category: "park", governorate: "nineveh", address: "الغابات", lat: 36.3667, lon: 43.1486, rating: 4.4, reviews: 4600, tags: ["طبيعة", "عوائل", "نزهة"], description: "رئة الموصل الخضراء على دجلة.", source: "local" },

  // ===== أربيل =====
  { id: "ebl-001", name: "قلعة أربيل التاريخية", category: "landmark", governorate: "erbil", address: "وسط أربيل", lat: 36.1912, lon: 44.0092, rating: 4.8, reviews: 8900, tags: ["يونسكو", "تراث", "سياحة"], description: "أقدم مستوطنة مأهولة في العالم، تراث يونسكو.", source: "local" },
  { id: "ebl-002", name: "مول فاميلي أربيل", category: "mall", governorate: "erbil", address: "طريق 100م", lat: 36.2056, lon: 43.9912, rating: 4.5, reviews: 6700, tags: ["تسوق", "ترفيه", "سينما"], hours: "10ص - 11م", description: "وجهة التسوق والترفيه الأولى في كوردستان.", source: "local" },
  { id: "ebl-003", name: "مطار أربيل الدولي", category: "station", governorate: "erbil", address: "طريق المطار", lat: 36.235, lon: 43.9632, rating: 4.3, reviews: 5400, tags: ["سفر", "دولي"], description: "أحدث مطارات العراق.", source: "local" },
  { id: "ebl-004", name: "مطعم نارنج · مشويات", category: "restaurant", governorate: "erbil", address: "عينكاوة", lat: 36.2165, lon: 43.9856, rating: 4.6, reviews: 2400, tags: ["مشويات", "عائلي"], description: "مشويات ومقبلات راقية في عينكاوة.", source: "local" },
  { id: "ebl-005", name: "بارك سامي عبد الرحمن", category: "park", governorate: "erbil", address: "60م", lat: 36.1865, lon: 44.0156, rating: 4.6, reviews: 5800, tags: ["رياضة", "عوائل", "بحيرة"], description: "أكبر باركات أربيل مع بحيرة ومسارات.", source: "local" },

  // ===== السليمانية =====
  { id: "sly-001", name: "جبل أزمر السياحي", category: "landmark", governorate: "sulaymaniyah", address: "أزمر", lat: 35.5789, lon: 45.4523, rating: 4.7, reviews: 3900, tags: ["جبال", "إطلالة", "تلفريك"], description: "إطلالة بانورامية على السليمانية.", source: "local" },
  { id: "sly-002", name: "مول سيتي ستار", category: "mall", governorate: "sulaymaniyah", address: "شارع سالم", lat: 35.5612, lon: 45.4345, rating: 4.3, reviews: 2900, tags: ["تسوق"], description: "مول مركزي في قلب السليمانية.", source: "local" },

  // ===== دهوك =====
  { id: "dhk-001", name: "سد دهوك السياحي", category: "park", governorate: "duhok", address: "سد دهوك", lat: 36.8856, lon: 42.9934, rating: 4.5, reviews: 2100, tags: ["طبيعة", "بحيرة", "نزهة"], description: "بحيرة ومتنفس سياحي جميل.", source: "local" },
  { id: "dhk-002", name: "مول دهوك · مازي", category: "mall", governorate: "duhok", address: "شارع KRO", lat: 36.8678, lon: 42.9891, rating: 4.2, reviews: 1800, tags: ["تسوق"], description: "أشهر مولات دهوك.", source: "local" },

  // ===== كركوك =====
  { id: "krk-001", name: "قلعة كركوك", category: "landmark", governorate: "kirkuk", address: "وسط كركوك", lat: 35.4708, lon: 44.3878, rating: 4.4, reviews: 2600, tags: ["تراث", "تاريخ"], description: "قلعة أثرية وسط المدينة.", source: "local" },
  { id: "krk-002", name: "مستشفى كركوك العام", category: "hospital", governorate: "kirkuk", address: "طريق بغداد", lat: 35.4623, lon: 44.3989, rating: 3.7, reviews: 1500, tags: ["طوارئ"], description: "المستشفى الحكومي الرئيسي.", source: "local" },

  // ===== كربلاء =====
  { id: "kbl-001", name: "العتبة الحسينية المقدسة", category: "mosque", governorate: "karbala", address: "وسط كربلاء", lat: 32.6165, lon: 44.0322, rating: 5.0, reviews: 45000, tags: ["زيارة", "ديني", "الحسين"], description: "مرقد الإمام الحسين عليه السلام.", source: "local" },
  { id: "kbl-002", name: "العتبة العباسية المقدسة", category: "mosque", governorate: "karbala", address: "بين الحرمين", lat: 32.6175, lon: 44.0365, rating: 5.0, reviews: 38000, tags: ["زيارة", "ديني", "العباس"], description: "مرقد أبي الفضل العباس عليه السلام.", source: "local" },
  { id: "kbl-003", name: "فندق البارون السياحي", category: "hotel", governorate: "karbala", address: "شارع العباس", lat: 32.6198, lon: 44.0312, rating: 4.1, reviews: 1600, tags: ["زوار", "قريب الحرم"], description: "فندق مريح للزوار قرب الحرمين.", source: "local" },

  // ===== النجف =====
  { id: "njf-001", name: "مرقد الإمام علي عليه السلام", category: "mosque", governorate: "najaf", address: "النجف القديمة", lat: 32.0, lon: 44.33, rating: 5.0, reviews: 52000, tags: ["زيارة", "ديني"], description: "العتبة العلوية المقدسة.", source: "local" },
  { id: "njf-002", name: "مقبرة وادي السلام", category: "landmark", governorate: "najaf", address: "النجف", lat: 32.0067, lon: 44.3034, rating: 4.6, reviews: 8900, tags: ["تراث", "تاريخي"], description: "أكبر مقبرة في العالم.", source: "local" },
  { id: "njf-003", name: "سوق النجف الكبير", category: "market", governorate: "najaf", address: "قرب الحرم", lat: 32.0025, lon: 44.3325, rating: 4.3, reviews: 3400, tags: ["تسوق", "هدايا", "تراث"], description: "سوق تراثي للهدايا والحلويات.", source: "local" },

  // ===== بابل =====
  { id: "bbl-001", name: "آثار بابل · بوابة عشتار", category: "landmark", governorate: "babil", address: "بابل الأثرية", lat: 32.5355, lon: 44.4205, rating: 4.7, reviews: 4600, tags: ["يونسكو", "آثار", "سياحة"], description: "مدينة بابل الأثرية وبوابة عشتار.", source: "local" },

  // ===== ذي قار =====
  { id: "dqr-001", name: "زقورة أور الأثرية", category: "landmark", governorate: "dhiqar", address: "التل، الناصرية", lat: 30.9625, lon: 46.1031, rating: 4.8, reviews: 2800, tags: ["آثار", "سومر", "سياحة"], description: "زقورة أور السومرية العريقة.", source: "local" },
  { id: "dqr-002", name: "أهوار الجبايش", category: "park", governorate: "dhiqar", address: "الجبايش", lat: 30.95, lon: 46.75, rating: 4.9, reviews: 1900, tags: ["طبيعة", "يونسكو", "مشحوف"], description: "أهوار الجنوب الساحرة برحلات المشحوف.", source: "local" },

  // ===== الأنبار / صلاح الدين / ديالى / واسط / ميسان / المثنى / القادسية =====
  { id: "anb-001", name: "بحيرة الحبانية السياحية", category: "park", governorate: "anbar", address: "الحبانية", lat: 33.3056, lon: 43.5656, rating: 4.2, reviews: 2100, tags: ["بحيرة", "مصيف", "عوائل"], description: "منتجع الحبانية على البحيرة.", source: "local" },
  { id: "sld-001", name: "مرقد الإمامين العسكريين", category: "mosque", governorate: "salahuddin", address: "سامراء", lat: 34.1987, lon: 43.8734, rating: 4.9, reviews: 12000, tags: ["زيارة", "سامراء"], description: "العتبة العسكرية في سامراء.", source: "local" },
  { id: "sld-002", name: "الملوية · مئذنة سامراء", category: "landmark", governorate: "salahuddin", address: "سامراء", lat: 34.2072, lon: 43.8745, rating: 4.8, reviews: 3400, tags: ["يونسكو", "عباسي", "آثار"], description: "مئذنة الملوية الحلزونية الشهيرة.", source: "local" },
  { id: "dyl-001", name: "بساتين البرتقال · بعقوبة", category: "park", governorate: "diyala", address: "بعقوبة", lat: 33.7523, lon: 44.6323, rating: 4.1, reviews: 900, tags: ["طبيعة", "بساتين"], description: "بساتين ديالى الخضراء.", source: "local" },
  { id: "wst-001", name: "كورنيش الكوت", category: "park", governorate: "wasit", address: "الكوت، دجلة", lat: 32.5123, lon: 45.8234, rating: 4.0, reviews: 1100, tags: ["كورنيش", "عوائل"], description: "كورنيش دجلة في الكوت.", source: "local" },
  { id: "mys-001", name: "هور الحويزة", category: "park", governorate: "maysan", address: "الحدود الشرقية", lat: 31.65, lon: 47.65, rating: 4.6, reviews: 800, tags: ["أهوار", "طبيعة"], description: "من أجمل أهوار ميسان.", source: "local" },
  { id: "mth-001", name: "سوق السماوة المسقوف", category: "market", governorate: "muthanna", address: "وسط السماوة", lat: 31.3256, lon: 45.2812, rating: 4.0, reviews: 700, tags: ["شعبي", "تراث"], description: "سوق السماوة التراثي.", source: "local" },
  { id: "qds-001", name: "آثار نفر · نيبور", category: "landmark", governorate: "qadisiyah", address: "عفك", lat: 32.1289, lon: 45.2308, rating: 4.5, reviews: 600, tags: ["آثار", "سومر"], description: "مدينة نفر السومرية الأثرية.", source: "local" },

  // إضافات بغداد للبحث الذكي
  { id: "bgd-016", name: "مستشفى ابن سينا الخاص", category: "hospital", governorate: "baghdad", address: "المنصور", lat: 33.3123, lon: 44.3456, rating: 4.3, reviews: 1800, tags: ["خاص", "طوارئ"], description: "مستشفى خاص بخدمات متكاملة.", source: "local" },
  { id: "bgd-017", name: "كافيه دجلة · على النهر", category: "cafe", governorate: "baghdad", address: "أبو نواس", lat: 33.3234, lon: 44.4123, rating: 4.5, reviews: 1500, tags: ["إطلالة", "نهر", "شيشة"], description: "كافيه بإطلالة مباشرة على دجلة.", source: "local" },
  { id: "bgd-018", name: "مصرف الرافدين · الفرع الرئيسي", category: "bank", governorate: "baghdad", address: "شارع الرشيد", lat: 33.3412, lon: 44.3945, rating: 3.6, reviews: 900, tags: ["حكومي", "صراف"], description: "الفرع الرئيسي لمصرف الرافدين.", source: "local" },
];

export const QUICK_CATEGORIES: { id: PlaceCategory; label: string; hint: string }[] = [
  { id: "restaurant", label: "مطاعم", hint: "مشويات، مسكوف، شعبية" },
  { id: "hospital", label: "مستشفيات", hint: "طوارئ ٢٤ ساعة" },
  { id: "fuel", label: "وقود", hint: "محطات قريبة" },
  { id: "mosque", label: "مراقد", hint: "زيارات دينية" },
  { id: "mall", label: "مولات", hint: "تسوق وترفيه" },
  { id: "pharmacy", label: "صيدليات", hint: "خافرة" },
  { id: "hotel", label: "فنادق", hint: "إقامة" },
  { id: "park", label: "متنزهات", hint: "عوائل" },
];

export const SMART_EXAMPLES = [
  "مطعم مشويات عائلي قريب من المنصور",
  "أقرب مستشفى طوارئ يعمل الآن",
  "مكان هادئ على النهر لشرب الشاي",
  "فندق نظيف قريب من الحرم في كربلاء",
  "صيدلية خافرة ٢٤ ساعة في الكرادة",
  "معلم أثري يستحق الزيارة جنوب العراق",
];
