import { useEffect, useMemo, useRef, useState } from "react";
import { Search, Sparkles, Mic, X, Clock, Trash2, SlidersHorizontal, Satellite, WifiOff } from "lucide-react";
import type { AppSettings, Place, PlaceCategory } from "../types";
import { CATEGORY_AR, GOVERNORATES, QUICK_CATEGORIES, SMART_EXAMPLES, govName } from "../data/iraq";
import { registry } from "../providers/core";
import "../providers/live";
import { smartSearch, type SmartResult } from "../providers/smart";
import { useSearchHistory } from "../store/storage";
import { haversineKm } from "../utils/geo";
import { Chip, EmptyState, PlaceCard, SectionTitle } from "../components/ui";
import { cn } from "../utils/cn";

interface ExploreProps {
  settings: AppSettings;
  online: boolean;
  userLoc: [number, number] | null;
  initialQuery: string;
  onOpenPlace: (p: Place) => void;
  onRouteTo: (p: Place) => void;
}

export default function Explore({ settings, online, userLoc, initialQuery, onOpenPlace, onRouteTo }: ExploreProps) {
  const [mode, setMode] = useState<"text" | "smart">("text");
  const [q, setQ] = useState(initialQuery);
  const [results, setResults] = useState<Place[]>([]);
  const [smart, setSmart] = useState<SmartResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [catFilter, setCatFilter] = useState<PlaceCategory | "all">("all");
  const [govFilter, setGovFilter] = useState("all");
  const [showFilters, setShowFilters] = useState(false);
  const [providerNote, setProviderNote] = useState("");
  const abortRef = useRef<AbortController | null>(null);
  const { items: history, push: pushHist, clear: clearHist, removeAt } = useSearchHistory();
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (initialQuery) {
      setQ(initialQuery);
      void runSearch(initialQuery, mode);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [initialQuery]);

  const runSearch = async (text: string, m: "text" | "smart" = mode) => {
    const query = text.trim();
    if (!query) { setResults([]); setSmart(null); return; }
    abortRef.current?.abort();
    abortRef.current = new AbortController();
    setLoading(true);
    setProviderNote("");
    pushHist({ q: query, at: Date.now(), mode: m });

    try {
      if (m === "smart") {
        const r = await smartSearch(query, settings, userLoc ?? undefined);
        let filtered = r.places;
        if (catFilter !== "all") filtered = filtered.filter((p) => p.category === catFilter);
        if (govFilter !== "all") filtered = filtered.filter((p) => p.governorate === govFilter);
        setSmart(r);
        setResults(filtered);
        setProviderNote(r.via === "ai-gateway" ? "عبر بوابة الذكاء الاصطناعي" : "عبر المحلل الدلالي المحلي");
      } else {
        const provider = registry.getSearch(online ? "hybrid" : "local");
        const list = await provider.search({
          text: query,
          near: userLoc ?? undefined,
          governorate: govFilter,
          limit: 14,
          signal: abortRef.current.signal,
        });
        const filtered = catFilter === "all" ? list : list.filter((p) => p.category === catFilter);
        setResults(filtered);
        setSmart(null);
        setProviderNote(online ? "عبر Nominatim + القاعدة المحلية" : "دون اتصال · القاعدة المحلية فقط");
      }
    } catch (e) {
      if ((e as Error).name !== "AbortError") {
        setResults([]);
        setProviderNote("تعذّر البحث، حاول مجددًا");
      }
    }
    setLoading(false);
  };

  // بحث تدريجي (debounce) للوضع النصي
  useEffect(() => {
    if (mode !== "text") return;
    if (!q.trim()) { setResults([]); return; }
    const t = setTimeout(() => void runSearch(q, "text"), 450);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [q, catFilter, govFilter, mode]);

  const distOf = (p: Place) =>
    userLoc ? haversineKm(userLoc[0], userLoc[1], p.lat, p.lon) * 1000 : undefined;

  const categories = useMemo(() => QUICK_CATEGORIES, []);

  return (
    <div className="mx-auto flex h-full w-full max-w-2xl flex-col px-4 pb-4 pt-4">
      {/* التبويب */}
      <div className="grid grid-cols-2 gap-1 rounded-2xl bg-slate-900/[0.06] p-1">
        <button
          onClick={() => setMode("text")}
          className={cn("flex items-center justify-center gap-2 rounded-xl py-2.5 text-[13px] font-black transition",
            mode === "text" ? "bg-white text-ink-900 shadow-card" : "text-slate-500")}
        >
          <Search size={15} /> بحث عادي
        </button>
        <button
          onClick={() => setMode("smart")}
          className={cn("flex items-center justify-center gap-2 rounded-xl py-2.5 text-[13px] font-black transition",
            mode === "smart" ? "bg-ink-900 text-gold-300 shadow-card" : "text-slate-500")}
        >
          <Sparkles size={15} /> ✨ بحث ذكي بالوصف
        </button>
      </div>

      {/* حقل البحث */}
      <form
        onSubmit={(e) => { e.preventDefault(); void runSearch(q, mode); inputRef.current?.blur(); }}
        className={cn(
          "mt-3 flex items-center gap-2 rounded-2xl bg-white p-2 pr-4 shadow-card ring-1 transition",
          mode === "smart" ? "ring-gold-400/60" : "ring-slate-900/5"
        )}
      >
        <span className={cn("flex h-9 w-9 shrink-0 items-center justify-center rounded-xl",
          mode === "smart" ? "bg-gold-400 text-ink-950" : "bg-ink-900 text-gold-400")}>
          {mode === "smart" ? <Sparkles size={17} /> : <Search size={17} />}
        </span>
        <input
          ref={inputRef}
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder={mode === "smart" ? "صِف ما تريد… مثل: مطعم مشويات عائلي قرب المنصور" : "ابحث: المتنبي، مستشفى، مول المنصور…"}
          className="w-full bg-transparent text-[14px] font-bold text-slate-800 outline-none placeholder:font-medium placeholder:text-slate-400"
        />
        {q && (
          <button type="button" onClick={() => { setQ(""); setResults([]); setSmart(null); }} className="rounded-full bg-slate-100 p-1.5 text-slate-500">
            <X size={14} />
          </button>
        )}
        <button type="button" className="rounded-xl bg-slate-100 p-2.5 text-slate-500 transition hover:bg-slate-200" aria-label="بحث صوتي">
          <Mic size={16} />
        </button>
        <button
          type="button"
          onClick={() => setShowFilters((v) => !v)}
          className={cn("rounded-xl p-2.5 transition", showFilters ? "bg-ink-900 text-white" : "bg-slate-100 text-slate-500")}
          aria-label="فلاتر"
        >
          <SlidersHorizontal size={16} />
        </button>
      </form>

      {/* الفلاتر */}
      {showFilters && (
        <div className="mt-2 animate-fade-up rounded-2xl bg-white p-3 shadow-card ring-1 ring-slate-900/5">
          <p className="mb-2 text-[12px] font-black text-slate-700">المحافظة</p>
          <div className="flex gap-1.5 overflow-x-auto no-scrollbar pb-1">
            <Chip active={govFilter === "all"} onClick={() => setGovFilter("all")}>كل العراق</Chip>
            {GOVERNORATES.map((g) => (
              <Chip key={g.id} active={govFilter === g.id} onClick={() => setGovFilter(g.id)}>
                {g.name.split("·")[0].trim()}
              </Chip>
            ))}
          </div>
          <p className="mb-2 mt-3 text-[12px] font-black text-slate-700">التصنيف</p>
          <div className="flex gap-1.5 overflow-x-auto no-scrollbar pb-1">
            <Chip active={catFilter === "all"} onClick={() => setCatFilter("all")}>الكل</Chip>
            {(Object.keys(CATEGORY_AR) as PlaceCategory[]).map((c) => (
              <Chip key={c} active={catFilter === c} onClick={() => setCatFilter(c)}>{CATEGORY_AR[c]}</Chip>
            ))}
          </div>
        </div>
      )}

      {/* حالة المزوّد */}
      {providerNote && (
        <div className="mt-2 flex items-center justify-center gap-1.5 text-[11px] font-bold text-slate-500">
          {online ? <Satellite size={12} className="text-emerald-600" /> : <WifiOff size={12} className="text-amber-600" />}
          {providerNote} · {results.length} نتيجة
        </div>
      )}

      <div className="mt-3 flex-1 overflow-y-auto pb-24">
        {/* شرح نية البحث الذكي */}
        {mode === "smart" && smart && (
          <div className="mb-3 animate-fade-up rounded-2xl bg-gradient-to-l from-ink-900 to-primary-700 p-3.5 text-white shadow-card">
            <div className="flex items-center gap-2 text-[12px] font-black text-gold-300">
              <Sparkles size={14} /> فهم الطلب
            </div>
            <p className="mt-1 text-[13px] font-bold leading-6">{smart.intent.explanation}</p>
            <div className="mt-2 flex flex-wrap gap-1.5">
              {smart.intent.category !== "any" && (
                <span className="rounded-full bg-white/15 px-2.5 py-1 text-[11px] font-bold">
                  {CATEGORY_AR[smart.intent.category as PlaceCategory]}
                </span>
              )}
              {smart.intent.governorate !== "any" && (
                <span className="rounded-full bg-white/15 px-2.5 py-1 text-[11px] font-bold">
                  📍 {govName(smart.intent.governorate)}
                </span>
              )}
              {smart.intent.openNow && <span className="rounded-full bg-emerald-400/20 px-2.5 py-1 text-[11px] font-bold">🟢 يعمل الآن</span>}
              {smart.intent.minRating > 0 && <span className="rounded-full bg-white/15 px-2.5 py-1 text-[11px] font-bold">⭐ +{smart.intent.minRating}</span>}
            </div>
          </div>
        )}

        {loading && (
          <div className="flex flex-col items-center py-10">
            <div className="h-10 w-10 animate-spin rounded-full border-[3px] border-primary-100 border-t-primary-600" />
            <p className="mt-3 text-[13px] font-bold text-slate-500">
              {mode === "smart" ? "الذكاء الاصطناعي يفهم طلبك…" : "جارٍ البحث في العراق…"}
            </p>
          </div>
        )}

        {!loading && results.length > 0 && (
          <div className="flex flex-col gap-2.5">
            {results.map((p, i) => (
              <div key={p.id} className="animate-fade-up" style={{ animationDelay: `${Math.min(i, 8) * 40}ms` }}>
                <PlaceCard
                  place={p}
                  distanceM={distOf(p)}
                  onOpen={() => onOpenPlace(p)}
                  onRoute={() => onRouteTo(p)}
                />
              </div>
            ))}
          </div>
        )}

        {!loading && results.length === 0 && !q && (
          <div className="flex flex-col gap-4">
            {mode === "smart" ? (
              <>
                <SectionTitle title="جرّب أن تصف…" sub="اكتب بلهجتك وسنفهم قصدك" />
                <div className="flex flex-col gap-2">
                  {SMART_EXAMPLES.map((ex) => (
                    <button
                      key={ex}
                      onClick={() => { setQ(ex); void runSearch(ex, "smart"); }}
                      className="flex items-center gap-3 rounded-2xl bg-white p-3.5 text-right shadow-card ring-1 ring-slate-900/5 transition hover:-translate-y-0.5 hover:ring-gold-400/50 active:scale-[0.99]"
                    >
                      <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-gold-400/20 text-base">✨</span>
                      <span className="text-[13px] font-bold text-slate-700">{ex}</span>
                    </button>
                  ))}
                </div>
              </>
            ) : (
              <>
                <SectionTitle title="تصفح حسب التصنيف" sub="وجهات مختارة في عموم العراق" />
                <div className="grid grid-cols-4 gap-2">
                  {categories.map((c) => (
                    <button
                      key={c.id}
                      onClick={() => { setQ(c.label); void runSearch(c.label, "text"); }}
                      className="flex flex-col items-center gap-1.5 rounded-2xl bg-white p-3 shadow-card ring-1 ring-slate-900/5 transition hover:-translate-y-0.5 active:scale-95"
                    >
                      <span className="text-2xl">{c.id === "restaurant" ? "🍖" : c.id === "hospital" ? "🏥" : c.id === "fuel" ? "⛽" : c.id === "mosque" ? "🕌" : c.id === "mall" ? "🛍️" : c.id === "pharmacy" ? "💊" : c.id === "hotel" ? "🏨" : "🌳"}</span>
                      <span className="text-[11px] font-black text-slate-700">{c.label}</span>
                    </button>
                  ))}
                </div>
              </>
            )}

            {history.length > 0 && (
              <>
                <SectionTitle
                  title="عمليات البحث الأخيرة"
                  action={
                    <button onClick={clearHist} className="flex items-center gap-1 text-[11px] font-bold text-red-500">
                      <Trash2 size={12} /> مسح
                    </button>
                  }
                />
                <div className="flex flex-col gap-1.5">
                  {history.slice(0, 6).map((h, i) => (
                    <div key={`${h.at}-${i}`} className="group flex items-center gap-2 rounded-xl bg-white/70 px-3 py-2.5 ring-1 ring-slate-900/5">
                      <Clock size={14} className="shrink-0 text-slate-400" />
                      <button
                        onClick={() => { setQ(h.q); setMode(h.mode); void runSearch(h.q, h.mode); }}
                        className="flex-1 truncate text-right text-[13px] font-bold text-slate-700"
                      >
                        {h.q}
                      </button>
                      {h.mode === "smart" && <span className="text-[10px] font-black text-gold-500">ذكي</span>}
                      <button onClick={() => removeAt(i)} className="text-slate-300 hover:text-red-500">
                        <X size={14} />
                      </button>
                    </div>
                  ))}
                </div>
              </>
            )}
          </div>
        )}

        {!loading && results.length === 0 && q && (
          <EmptyState
            emoji="🔍"
            title="لا نتائج مطابقة"
            sub="جرّب كلمة أخرى أو غيّر المحافظة، أو استخدم البحث الذكي بالوصف"
            action={
              <button
                onClick={() => { setMode("smart"); void runSearch(q, "smart"); }}
                className="rounded-xl bg-ink-900 px-4 py-2.5 text-[13px] font-black text-gold-300"
              >
                ✨ جرّب البحث الذكي
              </button>
            }
          />
        )}
      </div>
    </div>
  );
}
