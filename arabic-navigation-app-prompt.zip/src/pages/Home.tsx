import { useEffect, useMemo, useRef, useState } from "react";
import {
  Search, Navigation, X, ArrowLeftRight, Footprints, Car, Volume2,
  VolumeX, ChevronUp, Crosshair, Clock, Route as RouteIcon, Play, Square,
  BookmarkPlus, BookmarkCheck, Phone,
} from "lucide-react";
import MapView, { LocateButton } from "../components/MapView";
import { CategoryPill, Stars } from "../components/ui";
import { CATEGORY_ICON } from "../components/ui";
import type { AppSettings, Place, RouteResult } from "../types";
import { GOVERNORATES, LOCAL_PLACES, QUICK_CATEGORIES, govName } from "../data/iraq";
import { registry } from "../providers/core";
import "../providers/live";
import { cacheRoute, getCachedRoute, useRouteHistory, useSaved } from "../store/storage";
import { formatDistance, formatDuration, haversineKm, pointAlong } from "../utils/geo";
import { cn } from "../utils/cn";

interface HomeProps {
  settings: AppSettings;
  online: boolean;
  center: [number, number];
  setCenter: (c: [number, number]) => void;
  zoom: number;
  setZoom: (z: number) => void;
  userLoc: [number, number] | null;
  locate: () => void;
  locating: boolean;
  goExplore: (q?: string) => void;
  pendingDest: Place | null;
  setPendingDest: (p: Place | null) => void;
}

export default function Home({
  settings, online, center, setCenter, zoom, setZoom,
  userLoc, locate, locating, goExplore, pendingDest, setPendingDest,
}: HomeProps) {
  const [selected, setSelected] = useState<Place | null>(null);
  const [sheetOpen, setSheetOpen] = useState(false);
  const [routing, setRouting] = useState(false);
  const [route, setRoute] = useState<RouteResult | null>(null);
  const [routeErr, setRouteErr] = useState<string | null>(null);
  const [fromName, setFromName] = useState("موقعي الحالي");
  const [profile, setProfile] = useState<"driving" | "walking">("driving");
  const [navigating, setNavigating] = useState(false);
  const [navFrac, setNavFrac] = useState(0);
  const [voice, setVoice] = useState(settings.voiceGuidance);
  const [govFilter, setGovFilter] = useState("baghdad");
  const navTimer = useRef<number | null>(null);
  const { push: pushRoute } = useRouteHistory();
  const { items: saved, push: savePlace, replace: replaceSaved, isSaved } = useSaved();

  const origin: [number, number] = useMemo(() => {
    if (userLoc) return userLoc;
    const g = GOVERNORATES.find((x) => x.id === govFilter);
    if (g) return [g.lat, g.lon];
    return [33.3152, 44.3661];
  }, [userLoc, govFilter]);

  // وجهة معلّقة من صفحات أخرى
  useEffect(() => {
    if (pendingDest) {
      setSelected(pendingDest);
      setSheetOpen(true);
      setCenter([pendingDest.lat, pendingDest.lon]);
      setZoom(14);
      setPendingDest(null);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pendingDest]);

  // علامات قريبة من المركز
  const nearbyMarkers = useMemo(() => {
    return LOCAL_PLACES
      .map((p) => ({ p, d: haversineKm(center[0], center[1], p.lat, p.lon) }))
      .filter((x) => x.d < (zoom >= 12 ? 12 : 60))
      .sort((a, b) => a.d - b.d)
      .slice(0, 14)
      .map((x) => x.p);
  }, [center, zoom]);

  const markers = useMemo(() => {
    const list = [...nearbyMarkers];
    if (selected && !list.some((m) => m.id === selected.id)) list.push(selected);
    return list;
  }, [nearbyMarkers, selected]);

  const speak = (text: string) => {
    if (!voice) return;
    try {
      speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(text);
      u.lang = "ar-SA";
      u.rate = 1;
      speechSynthesis.speak(u);
    } catch { /* غير مدعوم */ }
  };

  const fetchRoute = async (dest: Place) => {
    setRouting(true);
    setRouteErr(null);
    setRoute(null);
    const key = `${origin[0].toFixed(4)},${origin[1].toFixed(4)}-${dest.lat.toFixed(4)},${dest.lon.toFixed(4)}`;
    // 1) الكاش أولًا (يخدم دون اتصال)
    const cached = getCachedRoute<RouteResult>(key);
    if (cached && (!online || settings.offlineMode)) {
      setRoute({ ...cached, provider: `${cached.provider} · مخزّن` });
      setRouting(false);
      return;
    }
    // 2) حي عبر OSRM
    if (online && !settings.offlineMode) {
      try {
        const r = await registry.getRouting("osrm").route({
          from: origin, to: [dest.lat, dest.lon],
          fromName, toName: dest.name, profile,
        });
        setRoute(r);
        cacheRoute(key, r);
        pushRoute({
          id: `${Date.now()}`, fromName, toName: dest.name,
          from: origin, to: [dest.lat, dest.lon],
          distanceM: r.distanceM, durationS: r.durationS,
          at: Date.now(), provider: "osrm",
        });
        setRouting(false);
        return;
      } catch {
        // سقوط إلى التقديري
      }
    }
    // 3) التقديري المحلي
    try {
      const r = await registry.getRouting("crowfly").route({
        from: origin, to: [dest.lat, dest.lon],
        fromName, toName: dest.name, profile,
      });
      if (cached) {
        setRoute({ ...cached, provider: `${cached.provider} · مخزّن` });
      } else {
        setRoute({ ...r, provider: "crowfly · تقديري" });
        cacheRoute(key, r);
      }
    } catch {
      setRouteErr("تعذّر حساب المسار. تحقق من الاتصال وحاول مجددًا.");
    }
    setRouting(false);
  };

  // بدء/إيقاف الملاحة (محاكاة تقدّم على المسار)
  const toggleNav = () => {
    if (navigating) {
      setNavigating(false);
      if (navTimer.current) window.clearInterval(navTimer.current);
      try { speechSynthesis.cancel(); } catch { /* noop */ }
      return;
    }
    if (!route) return;
    setNavigating(true);
    setNavFrac(0);
    speak(`بدء التوجيه إلى ${route.toName}. المسافة ${formatDistance(route.distanceM)} والمدة ${formatDuration(route.durationS)}.`);
    let stepIdx = -1;
    navTimer.current = window.setInterval(() => {
      setNavFrac((f) => {
        const nf = f + 0.012;
        if (nf >= 1) {
          if (navTimer.current) window.clearInterval(navTimer.current);
          setNavigating(false);
          speak("لقد وصلت إلى وجهتك. شكرًا لاستخدام السحاب.");
          return 1;
        }
        // إعلان الخطوات
        if (route.steps.length > 0) {
          const idx = Math.min(route.steps.length - 1, Math.floor(nf * route.steps.length));
          if (idx !== stepIdx) {
            stepIdx = idx;
            speak(route.steps[idx].instruction);
          }
        }
        return nf;
      });
    }, 900);
  };

  useEffect(() => () => {
    if (navTimer.current) window.clearInterval(navTimer.current);
  }, []);

  const navPos: [number, number] | null = useMemo(() => {
    if (!navigating || !route) return null;
    const p = pointAlong(route.geometry, navFrac);
    return [p.lat, p.lon];
  }, [navigating, route, navFrac]);

  // تتبع الملاحة: حرّك المركز مع المؤشر
  useEffect(() => {
    if (navPos) setCenter(navPos);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [navPos?.[0], navPos?.[1]]);

  const currentStep = useMemo(() => {
    if (!route || !navigating) return null;
    return route.steps[Math.min(route.steps.length - 1, Math.floor(navFrac * route.steps.length))] ?? null;
  }, [route, navigating, navFrac]);

  const toggleSave = (p: Place) => {
    if (isSaved(p.id)) {
      replaceSaved(saved.filter((s) => s.id !== p.id));
    } else {
      savePlace({ ...p, savedAt: Date.now(), label: "fav" });
    }
  };

  const remainingM = route ? route.distanceM * (1 - navFrac) : 0;
  const remainingS = route ? route.durationS * (1 - navFrac) : 0;

  return (
    <div className="relative flex h-full flex-col">
      {/* شريط البحث العائم */}
      <div className="pointer-events-none absolute inset-x-3 top-3 z-40">
        <div className="pointer-events-auto flex items-center gap-2">
          <button
            onClick={() => goExplore()}
            className="flex flex-1 items-center gap-3 rounded-2xl bg-white/95 px-4 py-3 text-right shadow-app ring-1 ring-slate-900/10 backdrop-blur transition hover:shadow-card active:scale-[0.99]"
          >
            <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-ink-900 text-gold-400">
              <Search size={17} />
            </span>
            <span className="flex-1">
              <span className="block text-[13px] font-extrabold text-slate-800">إلى أين تريد الذهاب؟</span>
              <span className="block text-[11px] text-slate-500">ابحث عن مكان، مطعم، مستشفى…</span>
            </span>
          </button>
          <LocateButton onClick={locate} loading={locating} />
        </div>

        {/* فلاتر المحافظات السريع */}
        {!navigating && (
          <div className="pointer-events-auto mt-2 flex gap-1.5 overflow-x-auto no-scrollbar pb-1">
            {GOVERNORATES.slice(0, 8).map((g) => (
              <button
                key={g.id}
                onClick={() => {
                  setGovFilter(g.id);
                  setCenter([g.lat, g.lon]);
                  setZoom(g.zoom);
                }}
                className={cn(
                  "shrink-0 rounded-full px-3 py-1.5 text-[12px] font-bold shadow-card backdrop-blur transition active:scale-95",
                  govFilter === g.id ? "bg-ink-900 text-white" : "bg-white/90 text-slate-700"
                )}
              >
                {g.name.split("·")[0].trim()}
              </button>
            ))}
          </div>
        )}

        {/* لافتة الملاحة النشطة */}
        {navigating && route && (
          <div className="pointer-events-auto mt-2 animate-slide-up rounded-2xl bg-ink-900 p-4 text-white shadow-app">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-[11px] font-bold text-gold-300">
                <Navigation size={12} /> توجيه نشط · {route.provider.includes("مخزّن") ? "مسار مخزّن" : route.provider.includes("crowfly") ? "مسار تقديري" : "مسار حي"}
              </div>
              <button onClick={() => setVoice((v) => !v)} className="rounded-full bg-white/10 p-1.5">
                {voice ? <Volume2 size={15} /> : <VolumeX size={15} />}
              </button>
            </div>
            <p className="mt-2 text-[17px] font-black leading-7">{currentStep?.instruction ?? "استعد…"}</p>
            <div className="mt-2 flex items-center gap-3 text-[12px] font-bold text-white/80">
              <span className="flex items-center gap-1"><RouteIcon size={13} /> {formatDistance(remainingM)} متبقٍ</span>
              <span className="flex items-center gap-1"><Clock size={13} /> {formatDuration(remainingS)}</span>
            </div>
            <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-white/15">
              <div className="h-full rounded-full bg-gold-400 transition-all" style={{ width: `${navFrac * 100}%` }} />
            </div>
          </div>
        )}
      </div>

      {/* الخريطة */}
      <MapView
        center={center}
        zoom={zoom}
        onCenterChange={setCenter}
        onZoomChange={setZoom}
        markers={markers}
        selectedId={selected?.id}
        onMarkerClick={(p) => { setSelected(p); setSheetOpen(true); }}
        routeGeom={route?.geometry ?? null}
        userLocation={userLoc}
        navPosition={navPos}
        dark={settings.mapStyle === "dark"}
        online={online}
        className="h-full w-full flex-1"
      />

      {/* الإجراءات السريعة */}
      {!selected && !navigating && (
        <div className="absolute inset-x-0 bottom-3 z-30 px-3">
          <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
            {QUICK_CATEGORIES.map((c) => (
              <button
                key={c.id}
                onClick={() => goExplore(c.label)}
                className="flex shrink-0 items-center gap-2 rounded-2xl bg-white/95 px-3.5 py-2.5 shadow-app ring-1 ring-slate-900/5 backdrop-blur transition hover:-translate-y-0.5 active:scale-95"
              >
                <span className="text-lg">{CATEGORY_ICON[c.id]}</span>
                <span className="text-right">
                  <span className="block text-[12px] font-black text-slate-800">{c.label}</span>
                  <span className="block text-[10px] text-slate-500">{c.hint}</span>
                </span>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* زر إنهاء الملاحة */}
      {navigating && (
        <div className="absolute inset-x-3 bottom-3 z-40">
          <button
            onClick={toggleNav}
            className="flex w-full items-center justify-center gap-2 rounded-2xl bg-red-600 py-3.5 text-[15px] font-black text-white shadow-app transition active:scale-[0.99]"
          >
            <Square size={17} className="fill-white" /> إنهاء التوجيه
          </button>
        </div>
      )}

      {/* الورقة السفلية: تفاصيل المكان + المسار */}
      {selected && !navigating && (
        <div className={cn(
          "absolute inset-x-0 bottom-0 z-40 max-h-[62%] overflow-y-auto rounded-t-[28px] bg-sand-50 shadow-app transition-transform",
          sheetOpen ? "translate-y-0" : "translate-y-[calc(100%-64px)]"
        )}>
          <button onClick={() => setSheetOpen((v) => !v)} className="sticky top-0 flex w-full flex-col items-center bg-sand-50 pb-1 pt-2.5">
            <span className="h-1.5 w-12 rounded-full bg-slate-300" />
          </button>
          <div className="px-4 pb-5">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-start gap-3">
                <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-primary-600 to-ink-900 text-3xl shadow-card">
                  {CATEGORY_ICON[selected.category]}
                </div>
                <div>
                  <h2 className="text-[18px] font-black leading-6 text-slate-900">{selected.name}</h2>
                  <p className="mt-1 text-xs text-slate-500">{selected.address} · {govName(selected.governorate)}</p>
                  <div className="mt-1.5 flex flex-wrap items-center gap-1.5">
                    <CategoryPill cat={selected.category} />
                    <Stars rating={selected.rating} />
                    {userLoc && (
                      <span className="text-[11px] font-bold text-slate-500">
                        يبعد {formatDistance(haversineKm(userLoc[0], userLoc[1], selected.lat, selected.lon) * 1000)}
                      </span>
                    )}
                  </div>
                </div>
              </div>
              <button
                onClick={() => { setSelected(null); setRoute(null); }}
                className="rounded-full bg-slate-100 p-2 text-slate-500 transition hover:bg-slate-200"
              >
                <X size={16} />
              </button>
            </div>

            {selected.description && (
              <p className="mt-3 rounded-2xl bg-white p-3 text-[13px] leading-6 text-slate-600 ring-1 ring-slate-900/5">
                {selected.description}
              </p>
            )}

            {/* مخطط المسار */}
            <div className="mt-3 rounded-2xl bg-white p-3 ring-1 ring-slate-900/5">
              <div className="flex items-center gap-2">
                <div className="flex flex-1 flex-col gap-2">
                  <div className="flex items-center gap-2 rounded-xl bg-slate-50 px-3 py-2.5 ring-1 ring-slate-100">
                    <Crosshair size={14} className="shrink-0 text-emerald-600" />
                    <input
                      value={fromName}
                      onChange={(e) => setFromName(e.target.value)}
                      className="w-full bg-transparent text-[13px] font-bold text-slate-800 outline-none"
                      placeholder="نقطة الانطلاق"
                    />
                  </div>
                  <div className="flex items-center gap-2 rounded-xl bg-primary-50 px-3 py-2.5 ring-1 ring-primary-100">
                    <Navigation size={14} className="shrink-0 text-primary-700" />
                    <span className="truncate text-[13px] font-bold text-slate-800">{selected.name}</span>
                  </div>
                </div>
                <button className="rounded-xl bg-slate-100 p-2.5 text-slate-500" aria-label="تبديل">
                  <ArrowLeftRight size={16} />
                </button>
              </div>
              <div className="mt-2 flex gap-2">
                <button
                  onClick={() => setProfile("driving")}
                  className={cn("flex flex-1 items-center justify-center gap-1.5 rounded-xl py-2 text-[12px] font-black transition",
                    profile === "driving" ? "bg-ink-900 text-white" : "bg-slate-100 text-slate-500")}
                >
                  <Car size={15} /> سيارة
                </button>
                <button
                  onClick={() => setProfile("walking")}
                  className={cn("flex flex-1 items-center justify-center gap-1.5 rounded-xl py-2 text-[12px] font-black transition",
                    profile === "walking" ? "bg-ink-900 text-white" : "bg-slate-100 text-slate-500")}
                >
                  <Footprints size={15} /> مشي
                </button>
                <button
                  onClick={() => toggleSave(selected)}
                  className={cn("rounded-xl p-2.5 transition",
                    isSaved(selected.id) ? "bg-gold-400 text-ink-950" : "bg-slate-100 text-slate-500")}
                >
                  {isSaved(selected.id) ? <BookmarkCheck size={17} /> : <BookmarkPlus size={17} />}
                </button>
                {selected.phone && (
                  <a href={`tel:${selected.phone}`} className="rounded-xl bg-emerald-100 p-2.5 text-emerald-700">
                    <Phone size={17} />
                  </a>
                )}
              </div>
              <button
                onClick={() => fetchRoute(selected)}
                disabled={routing}
                className="mt-2.5 flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-l from-primary-600 to-ink-900 py-3 text-[15px] font-black text-white shadow-card transition active:scale-[0.99] disabled:opacity-60"
              >
                {routing ? (
                  <>
                    <span className="h-4 w-4 animate-spin rounded-full border-2 border-white/40 border-t-white" />
                    جارٍ حساب المسار…
                  </>
                ) : (
                  <>🧭 احسب المسار {online ? "· حي" : "· دون اتصال"}</>
                )}
              </button>
              {routeErr && <p className="mt-2 text-center text-xs font-bold text-red-600">{routeErr}</p>}
            </div>

            {/* نتيجة المسار */}
            {route && (
              <div className="mt-3 animate-fade-up overflow-hidden rounded-2xl bg-ink-900 text-white shadow-card">
                <div className="flex items-center justify-between bg-white/5 px-4 py-3">
                  <div className="flex items-center gap-4">
                    <div>
                      <p className="text-[10px] font-bold text-white/60">المسافة</p>
                      <p className="text-[17px] font-black text-gold-300">{formatDistance(route.distanceM)}</p>
                    </div>
                    <div className="h-8 w-px bg-white/15" />
                    <div>
                      <p className="text-[10px] font-bold text-white/60">المدة</p>
                      <p className="text-[17px] font-black">{formatDuration(route.durationS)}</p>
                    </div>
                  </div>
                  <span className="rounded-full bg-white/10 px-2.5 py-1 text-[10px] font-bold text-white/80">
                    عبر {route.provider.includes("osrm") ? "OSRM حي" : route.provider.includes("مخزّن") ? "التخزين" : "تقديري"}
                  </span>
                </div>
                <div className="max-h-44 overflow-y-auto px-4 py-2">
                  {route.steps.slice(0, 12).map((s, i) => (
                    <div key={i} className="flex items-start gap-3 border-r-2 border-dashed border-white/15 py-2 pr-3 last:border-0">
                      <span className="flex h-6 w-6 shrink-0 -translate-x-0 items-center justify-center rounded-full bg-gold-400 text-[11px] font-black text-ink-950">
                        {i + 1}
                      </span>
                      <div className="flex-1">
                        <p className="text-[13px] font-bold leading-5">{s.instruction}</p>
                        <p className="text-[11px] text-white/55">{formatDistance(s.distanceM)} · {formatDuration(s.durationS)}</p>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="p-3">
                  <button
                    onClick={toggleNav}
                    className="flex w-full items-center justify-center gap-2 rounded-2xl bg-gold-400 py-3 text-[15px] font-black text-ink-950 transition hover:bg-gold-300 active:scale-[0.99]"
                  >
                    <Play size={17} className="fill-ink-950" /> بدء التوجيه الصوتي
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* تلميح السحب */}
      {!selected && !sheetOpen && !navigating && (
        <div className="pointer-events-none absolute bottom-24 left-1/2 z-20 flex -translate-x-1/2 items-center gap-1 rounded-full bg-ink-950/70 px-3 py-1.5 text-[11px] font-bold text-white/90 backdrop-blur">
          <ChevronUp size={13} /> اسحب الخريطة للاستكشاف · انقر أي علامة
        </div>
      )}
    </div>
  );
}
