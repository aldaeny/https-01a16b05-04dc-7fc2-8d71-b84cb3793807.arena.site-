import { useState } from "react";
import { Bookmark, History, Route as RouteIcon, Trash2, Home, Briefcase, Star, Navigation, MapPin, Clock } from "lucide-react";
import type { Place, SavedPlace } from "../types";
import { useRouteHistory, useSaved, useSearchHistory } from "../store/storage";
import { EmptyState, PlaceCard, SectionTitle } from "../components/ui";
import { formatDistance, formatDuration, formatTime } from "../utils/geo";
import { cn } from "../utils/cn";

interface SavedProps {
  onOpenPlace: (p: Place) => void;
  onRouteTo: (p: Place) => void;
}

type Tab = "saved" | "routes" | "history";

export default function Saved({ onOpenPlace, onRouteTo }: SavedProps) {
  const [tab, setTab] = useState<Tab>("saved");
  const { items: saved, removeAt: rmSaved, clear: clearSaved, replace } = useSaved();
  const { items: routes, removeAt: rmRoute, clear: clearRoutes } = useRouteHistory();
  const { items: hist, removeAt: rmHist, clear: clearHist } = useSearchHistory();
  const [labelFilter, setLabelFilter] = useState<"all" | SavedPlace["label"]>("all");

  const setLabel = (idx: number, label: SavedPlace["label"]) => {
    const next = saved.map((s, i) => (i === idx ? { ...s, label } : s));
    replace(next);
  };

  const filtered = labelFilter === "all" ? saved : saved.filter((s) => s.label === labelFilter);

  const tabs: { id: Tab; label: string; icon: typeof Bookmark; count: number }[] = [
    { id: "saved", label: "المحفوظة", icon: Bookmark, count: saved.length },
    { id: "routes", label: "المسارات", icon: RouteIcon, count: routes.length },
    { id: "history", label: "السجل", icon: History, count: hist.length },
  ];

  return (
    <div className="mx-auto flex h-full w-full max-w-2xl flex-col px-4 pb-4 pt-4">
      <div className="grid grid-cols-3 gap-1 rounded-2xl bg-slate-900/[0.06] p-1">
        {tabs.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={cn(
              "flex items-center justify-center gap-1.5 rounded-xl py-2.5 text-[13px] font-black transition",
              tab === t.id ? "bg-white text-ink-900 shadow-card" : "text-slate-500"
            )}
          >
            <t.icon size={15} />
            {t.label}
            {t.count > 0 && (
              <span className={cn("rounded-full px-1.5 py-0.5 text-[10px] font-black",
                tab === t.id ? "bg-ink-900 text-white" : "bg-slate-200 text-slate-600")}>
                {t.count}
              </span>
            )}
          </button>
        ))}
      </div>

      <div className="mt-4 flex-1 overflow-y-auto pb-24">
        {tab === "saved" && (
          <>
            <div className="mb-3 flex gap-1.5 overflow-x-auto no-scrollbar">
              {([
                ["all", "الكل"], ["home", "🏠 المنزل"], ["work", "💼 العمل"], ["fav", "⭐ مفضلة"],
              ] as const).map(([id, label]) => (
                <button
                  key={id}
                  onClick={() => setLabelFilter(id)}
                  className={cn("shrink-0 rounded-full px-3.5 py-2 text-[12px] font-black transition active:scale-95",
                    labelFilter === id ? "bg-ink-900 text-white" : "bg-white text-slate-600 ring-1 ring-slate-200")}
                >
                  {label}
                </button>
              ))}
              {saved.length > 0 && (
                <button onClick={clearSaved} className="mr-auto flex shrink-0 items-center gap-1 rounded-full bg-red-50 px-3 py-2 text-[12px] font-black text-red-500">
                  <Trash2 size={13} /> مسح الكل
                </button>
              )}
            </div>
            {filtered.length === 0 ? (
              <EmptyState
                emoji="🔖"
                title={saved.length === 0 ? "لا أماكن محفوظة بعد" : "لا عناصر بهذا التصنيف"}
                sub="احفظ منزلك وعملك وأماكنك المفضلة لتصل إليها بضغطة واحدة — كلها على جهازك فقط"
              />
            ) : (
              <div className="flex flex-col gap-2.5">
                {filtered.map((s, i) => {
                  const realIdx = saved.findIndex((x) => x.id === s.id && x.savedAt === s.savedAt);
                  return (
                    <div key={`${s.id}-${s.savedAt}`} className="animate-fade-up" style={{ animationDelay: `${Math.min(i, 8) * 40}ms` }}>
                      <PlaceCard
                        place={s}
                        onOpen={() => onOpenPlace(s)}
                        onRoute={() => onRouteTo(s)}
                        trailing={
                          <div className="flex flex-1 items-center gap-1.5">
                            <div className="flex flex-1 gap-1">
                              {([
                                ["home", Home, "منزل"], ["work", Briefcase, "عمل"], ["fav", Star, "مفضل"],
                              ] as const).map(([lid, Icon, lbl]) => (
                                <button
                                  key={lid}
                                  onClick={() => setLabel(realIdx, lid)}
                                  className={cn("flex flex-1 items-center justify-center gap-1 rounded-lg py-2 text-[11px] font-black transition",
                                    s.label === lid ? "bg-gold-400 text-ink-950" : "bg-slate-100 text-slate-500")}
                                >
                                  <Icon size={12} /> {lbl}
                                </button>
                              ))}
                            </div>
                            <button onClick={() => rmSaved(realIdx)} className="rounded-lg bg-red-50 p-2 text-red-500">
                              <Trash2 size={15} />
                            </button>
                          </div>
                        }
                      />
                      <p className="mt-1 px-1 text-[10px] font-bold text-slate-400">حُفظ {formatTime(s.savedAt)}</p>
                    </div>
                  );
                })}
              </div>
            )}
          </>
        )}

        {tab === "routes" && (
          <>
            <SectionTitle
              title="سجل المسارات"
              sub="آخر مساراتك المحسوبة — تُحفظ محليًا وتعمل دون اتصال"
              action={routes.length > 0 ? (
                <button onClick={clearRoutes} className="flex items-center gap-1 text-[11px] font-bold text-red-500">
                  <Trash2 size={12} /> مسح
                </button>
              ) : undefined}
            />
            {routes.length === 0 ? (
              <EmptyState emoji="🛣️" title="لا مسارات بعد" sub="احسب مسارًا من الخريطة وسيُحفظ هنا تلقائيًا لاستخدامه دون اتصال" />
            ) : (
              <div className="flex flex-col gap-2.5">
                {routes.map((r, i) => (
                  <div key={r.id} className="animate-fade-up rounded-2xl bg-white p-3.5 shadow-card ring-1 ring-slate-900/5" style={{ animationDelay: `${Math.min(i, 8) * 40}ms` }}>
                    <div className="flex items-start gap-3">
                      <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-ink-900 text-lg">🛣️</div>
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-[14px] font-black text-slate-900">{r.fromName} ← {r.toName}</p>
                        <div className="mt-1 flex flex-wrap items-center gap-2 text-[11px] font-bold text-slate-500">
                          <span className="flex items-center gap-1"><MapPin size={11} /> {formatDistance(r.distanceM)}</span>
                          <span className="flex items-center gap-1"><Clock size={11} /> {formatDuration(r.durationS)}</span>
                          <span className="rounded-full bg-slate-100 px-2 py-0.5">{r.provider === "osrm" ? "حي" : r.provider}</span>
                        </div>
                        <p className="mt-1 text-[10px] font-bold text-slate-400">{formatTime(r.at)}</p>
                      </div>
                      <button onClick={() => rmRoute(i)} className="rounded-lg bg-red-50 p-2 text-red-400">
                        <Trash2 size={14} />
                      </button>
                    </div>
                    <button
                      onClick={() => onRouteTo({ id: `rehist-${r.id}`, name: r.toName, category: "landmark", governorate: "baghdad", address: r.toName, lat: r.to[0], lon: r.to[1], tags: [], source: "local" })}
                      className="mt-2.5 flex w-full items-center justify-center gap-2 rounded-xl bg-primary-50 py-2 text-[12px] font-black text-primary-700 transition hover:bg-primary-100"
                    >
                      <Navigation size={13} /> إعادة هذا المسار
                    </button>
                  </div>
                ))}
              </div>
            )}
          </>
        )}

        {tab === "history" && (
          <>
            <SectionTitle
              title="سجل البحث"
              sub="كل عمليات البحث على جهازك فقط"
              action={hist.length > 0 ? (
                <button onClick={clearHist} className="flex items-center gap-1 text-[11px] font-bold text-red-500">
                  <Trash2 size={12} /> مسح
                </button>
              ) : undefined}
            />
            {hist.length === 0 ? (
              <EmptyState emoji="🕘" title="السجل فارغ" sub="ابحث عن أي مكان وسيظهر هنا" />
            ) : (
              <div className="flex flex-col gap-1.5">
                {hist.map((h, i) => (
                  <div key={`${h.at}-${i}`} className="flex items-center gap-2 rounded-xl bg-white px-3 py-2.5 shadow-card ring-1 ring-slate-900/5">
                    <History size={14} className="shrink-0 text-slate-400" />
                    <span className="flex-1 truncate text-[13px] font-bold text-slate-700">{h.q}</span>
                    {h.mode === "smart" && <span className="text-[10px] font-black text-gold-500">ذكي</span>}
                    <span className="text-[10px] font-bold text-slate-400">{formatTime(h.at)}</span>
                    <button onClick={() => rmHist(i)} className="text-slate-300 hover:text-red-500">
                      <Trash2 size={13} />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
