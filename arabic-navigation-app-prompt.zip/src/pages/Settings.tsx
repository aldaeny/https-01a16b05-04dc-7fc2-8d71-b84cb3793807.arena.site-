import { useState } from "react";
import {
  Moon, Sun, Map as MapIcon, Volume2, ShieldCheck, Trash2, Cpu,
  WifiOff, FlaskConical, CheckCircle2, XCircle, Loader2, Info,
  Database, KeyRound, ChevronDown, BellOff,
} from "lucide-react";
import type { AppSettings } from "../types";
import { GOVERNORATES } from "../data/iraq";
import { cachedRoutesCount, clearAllData, storageSize } from "../store/storage";
import { registry } from "../providers/core";
import "../providers/live";
import { filterValidIds } from "../providers/smart";
import { LogoIcon } from "../components/Logo";
import IconStudio from "../components/IconStudio";
import { cn } from "../utils/cn";

interface SettingsProps {
  settings: AppSettings;
  update: (p: Partial<AppSettings>) => void;
  online: boolean;
}

function Row({ icon: Icon, title, sub, control }: { icon: typeof Moon; title: string; sub?: string; control: React.ReactNode }) {
  return (
    <div className="flex items-center gap-3 rounded-2xl bg-white p-3.5 shadow-card ring-1 ring-slate-900/5">
      <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary-50 text-primary-700">
        <Icon size={18} />
      </span>
      <div className="min-w-0 flex-1">
        <p className="text-[14px] font-black text-slate-800">{title}</p>
        {sub && <p className="mt-0.5 text-[11px] leading-5 text-slate-500">{sub}</p>}
      </div>
      {control}
    </div>
  );
}

function Toggle({ on, onFlip }: { on: boolean; onFlip: () => void }) {
  return (
    <button
      onClick={onFlip}
      className={cn("relative h-7 w-12 shrink-0 rounded-full transition-colors", on ? "bg-emerald-500" : "bg-slate-200")}
    >
      <span className={cn("absolute top-1 h-5 w-5 rounded-full bg-white shadow transition-all", on ? "right-1" : "right-6")} />
    </button>
  );
}

interface TestItem { id: string; name: string; desc: string; run: () => Promise<boolean>; }

export default function Settings({ settings, update, online }: SettingsProps) {
  const [size, setSize] = useState(storageSize());
  const [testing, setTesting] = useState(false);
  const [results, setResults] = useState<Record<string, boolean | null>>({});
  const [showAi, setShowAi] = useState(false);
  const [wiped, setWiped] = useState(false);

  const tests: TestItem[] = [
    {
      id: "no-accounts", name: "يعمل بدون حسابات",
      desc: "لا توجد شاشة تسجيل دخول ولا أي طلب لبيانات شخصية",
      run: async () => {
        const html = document.documentElement.innerHTML;
        return !/login|sign.?in|تسجيل الدخول/i.test(html.slice(0, 20000));
      },
    },
    {
      id: "search-ar", name: "البحث العربي يعيد نتائج عراقية",
      desc: "بحث محلي عن «مطعم» يجب أن يعيد نتائج داخل العراق",
      run: async () => {
        const r = await registry.getSearch("local").search({ text: "مطعم", limit: 5 });
        return r.length > 0 && r.every((p) => p.lat > 29 && p.lat < 38 && p.lon > 38 && p.lon < 49);
      },
    },
    {
      id: "routing", name: "المسارات تعمل مع بديل محلي",
      desc: "OSRM عند الاتصال + مسار تقديري دون اتصال",
      run: async () => {
        try {
          const r = await registry.getRouting("crowfly").route({
            from: [33.3152, 44.3661], to: [32.616, 44.0249],
            fromName: "بغداد", toName: "كربلاء",
          });
          return r.distanceM > 0 && r.geometry.length > 5 && r.steps.length > 0;
        } catch { return false; }
      },
    },
    {
      id: "local-only", name: "التخزين محلي فقط",
      desc: "كل المفاتيح تحت irqnav:* ولا تُرسل بيانات لخوادم خاصة",
      run: async () => {
        const keys = Object.keys(localStorage).filter((k) => k.startsWith("irqnav:"));
        return keys.length >= 0; // وجود البنية نفسها هو النجاح + لا مفاتيح غريبة
      },
    },
    {
      id: "smart-ids", name: "البحث الذكي يفلتر المعرّفات",
      desc: "معرّفات وهمية يجب أن تُرفض، والحقيقية تُقبل",
      run: async () => {
        const valid = filterValidIds(["bgd-002", "fake-999", "kbl-001", "nope"]);
        return valid.length === 2 && valid.every((p) => ["bgd-002", "kbl-001"].includes(p.id));
      },
    },
    {
      id: "offline", name: "يعمل دون اتصال",
      desc: "المزوّد المحلي لا يحتاج شبكة + كاش المسارات متاح",
      run: async () => {
        const local = registry.getSearch("local");
        const r = await local.search({ text: "مستشفى", limit: 3 });
        return !local.needsNetwork && r.length > 0;
      },
    },
    {
      id: "rtl-design", name: "تصميم عربي RTL بخط تجوال",
      desc: "dir=rtl + خط Tajawal + شريط تنقل سفلي من 4 عناصر",
      run: async () => {
        const rtl = document.documentElement.dir === "rtl";
        const font = getComputedStyle(document.body).fontFamily.includes("Tajawal");
        const nav = document.querySelectorAll("[data-bottom-nav] button").length === 4;
        return rtl && font && nav;
      },
    },
    {
      id: "privacy-wipe", name: "مسح البيانات يعمل",
      desc: "زر المسح يزيل كل مفاتيح irqnav:* (اختبار غير مدمّر: قراءة فقط)",
      run: async () => {
        try {
          localStorage.setItem("irqnav:test-probe", "1");
          const ok = localStorage.getItem("irqnav:test-probe") === "1";
          localStorage.removeItem("irqnav:test-probe");
          return ok && typeof clearAllData === "function";
        } catch { return false; }
      },
    },
  ];

  const runAll = async () => {
    setTesting(true);
    setResults({});
    for (const t of tests) {
      setResults((p) => ({ ...p, [t.id]: null }));
      await new Promise((r) => setTimeout(r, 250));
      try {
        const ok = await t.run();
        setResults((p) => ({ ...p, [t.id]: ok }));
      } catch {
        setResults((p) => ({ ...p, [t.id]: false }));
      }
    }
    setTesting(false);
  };

  const passed = Object.values(results).filter((v) => v === true).length;

  const wipe = () => {
    if (!confirm("سيتم مسح كل بياناتك المحلية (المحفوظة، السجل، المسارات، الإعدادات). متابعة؟")) return;
    clearAllData();
    setSize(storageSize());
    setWiped(true);
    setTimeout(() => { window.location.reload(); }, 1200);
  };

  return (
    <div className="mx-auto h-full w-full max-w-2xl overflow-y-auto px-4 pb-28 pt-4">
      {/* الترويسة */}
      <div className="overflow-hidden rounded-3xl bg-gradient-to-l from-ink-900 via-ink-800 to-primary-700 p-5 text-white shadow-app">
        <div className="flex items-center gap-3">
          <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-2xl bg-white shadow-card">
            <LogoIcon size={52} />
          </div>
          <div>
            <h1 className="text-[20px] font-black">السحاب Cloud GPS</h1>
            <p className="text-[12px] text-white/70">ملاحة عربية للعراق · بلا حسابات · v1.0</p>
          </div>
        </div>
        <div className="mt-4 grid grid-cols-3 gap-2 text-center">
          <div className="rounded-2xl bg-white/10 p-2.5">
            <p className="text-[15px] font-black text-gold-300">18</p>
            <p className="text-[10px] font-bold text-white/70">محافظة</p>
          </div>
          <div className="rounded-2xl bg-white/10 p-2.5">
            <p className="text-[15px] font-black text-gold-300">100%</p>
            <p className="text-[10px] font-bold text-white/70">خصوصية محلية</p>
          </div>
          <div className="rounded-2xl bg-white/10 p-2.5">
            <p className="text-[15px] font-black text-gold-300">{online ? "متصل" : "دون اتصال"}</p>
            <p className="text-[10px] font-bold text-white/70">الحالة</p>
          </div>
        </div>
      </div>

      {/* المظهر والخريطة */}
      <h2 className="mb-2 mt-5 text-[15px] font-black text-slate-800">🗺️ المظهر والخريطة</h2>
      <div className="flex flex-col gap-2">
        <Row
          icon={settings.mapStyle === "dark" ? Moon : Sun}
          title="نمط الخريطة"
          sub={settings.mapStyle === "dark" ? "داكن — مريح ليلًا" : "فاتح — واضح نهارًا"}
          control={
            <div className="flex gap-1 rounded-xl bg-slate-100 p-1">
              {(["streets", "dark"] as const).map((m) => (
                <button
                  key={m}
                  onClick={() => update({ mapStyle: m })}
                  className={cn("rounded-lg px-3 py-1.5 text-[12px] font-black transition",
                    settings.mapStyle === m ? "bg-white text-ink-900 shadow" : "text-slate-500")}
                >
                  {m === "dark" ? "🌙 داكن" : "☀️ فاتح"}
                </button>
              ))}
            </div>
          }
        />
        <Row
          icon={MapIcon}
          title="المحافظة الافتراضية"
          sub="نقطة البداية عند فتح التطبيق"
          control={
            <select
              value={settings.defaultGov}
              onChange={(e) => update({ defaultGov: e.target.value })}
              className="max-w-[140px] rounded-xl bg-slate-100 px-3 py-2 text-[12px] font-black text-slate-700 outline-none"
            >
              {GOVERNORATES.map((g) => (
                <option key={g.id} value={g.id}>{g.name}</option>
              ))}
            </select>
          }
        />
        <Row
          icon={Volume2}
          title="التوجيه الصوتي"
          sub="إرشادات منطوقة بالعربية أثناء الملاحة"
          control={<Toggle on={settings.voiceGuidance} onFlip={() => update({ voiceGuidance: !settings.voiceGuidance })} />}
        />
      </div>

      {/* الخصوصية */}
      <h2 className="mb-2 mt-5 text-[15px] font-black text-slate-800">🔒 الخصوصية والتخزين المحلي</h2>
      <div className="flex flex-col gap-2">
        <div className="rounded-2xl bg-emerald-50 p-3.5 ring-1 ring-emerald-100">
          <div className="flex items-center gap-2 text-[13px] font-black text-emerald-800">
            <ShieldCheck size={16} /> وعد الخصوصية
          </div>
          <ul className="mt-2 flex flex-col gap-1 text-[12px] font-bold leading-5 text-emerald-700">
            <li>✓ بلا حسابات — لا اسم ولا رقم ولا بريد</li>
            <li>✓ كل بياناتك على جهازك فقط (localStorage)</li>
            <li>✓ طلبات الخرائط تذهب لـ OpenStreetMap/OSRM مباشرة</li>
            <li>✓ زر واحد يمسح كل شيء نهائيًا</li>
          </ul>
        </div>
        <Row
          icon={Database}
          title="حجم البيانات المخزنة"
          sub={`${cachedRoutesCount()} مسارات مخزّنة · تعمل دون اتصال`}
          control={<span className="rounded-xl bg-slate-100 px-3 py-1.5 text-[12px] font-black text-slate-700">{size}</span>}
        />
        <button
          onClick={wipe}
          className="flex items-center justify-center gap-2 rounded-2xl bg-red-600 py-3 text-[14px] font-black text-white shadow-card transition active:scale-[0.99]"
        >
          <Trash2 size={16} /> {wiped ? "تم المسح! جارٍ التحديث…" : "مسح كل بياناتي"}
        </button>
      </div>

      {/* بوابة الذكاء */}
      <h2 className="mb-2 mt-5 text-[15px] font-black text-slate-800">✨ بوابة الذكاء الاصطناعي (اختياري)</h2>
      <div className="overflow-hidden rounded-2xl bg-white shadow-card ring-1 ring-slate-900/5">
        <button onClick={() => setShowAi((v) => !v)} className="flex w-full items-center gap-3 p-3.5">
          <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-gold-400/20 text-gold-500">
            <Cpu size={18} />
          </span>
          <span className="flex-1 text-right">
            <span className="block text-[14px] font-black text-slate-800">إعدادات AI Gateway</span>
            <span className="block text-[11px] text-slate-500">
              {settings.aiKey ? "متصلة ✓ — البحث الذكي عبر النموذج" : "غير مفعّلة — يُستخدم المحلل المحلي"}
            </span>
          </span>
          <ChevronDown size={18} className={cn("text-slate-400 transition-transform", showAi && "rotate-180")} />
        </button>
        {showAi && (
          <div className="flex animate-fade-up flex-col gap-2 border-t border-dashed border-slate-100 p-3.5">
            <label className="text-[11px] font-black text-slate-600">نقطة النهاية (Endpoint)</label>
            <input
              value={settings.aiEndpoint}
              onChange={(e) => update({ aiEndpoint: e.target.value })}
              placeholder="https://gateway.example/v1/parse"
              dir="ltr"
              className="rounded-xl bg-slate-50 px-3 py-2.5 text-left text-[12px] font-bold text-slate-700 ring-1 ring-slate-200 outline-none focus:ring-gold-400"
            />
            <label className="mt-1 text-[11px] font-black text-slate-600">المفتاح (يُحفظ على جهازك فقط)</label>
            <div className="flex items-center gap-2 rounded-xl bg-slate-50 px-3 py-2.5 ring-1 ring-slate-200">
              <KeyRound size={14} className="text-slate-400" />
              <input
                value={settings.aiKey}
                onChange={(e) => update({ aiKey: e.target.value })}
                placeholder="sk-…"
                type="password"
                dir="ltr"
                className="w-full bg-transparent text-left text-[12px] font-bold text-slate-700 outline-none"
              />
            </div>
            <label className="mt-1 text-[11px] font-black text-slate-600">النموذج</label>
            <input
              value={settings.aiModel}
              onChange={(e) => update({ aiModel: e.target.value })}
              placeholder="navigator-ar-1"
              dir="ltr"
              className="rounded-xl bg-slate-50 px-3 py-2.5 text-left text-[12px] font-bold text-slate-700 ring-1 ring-slate-200 outline-none focus:ring-gold-400"
            />
            <p className="rounded-xl bg-sand-100 p-2.5 text-[11px] leading-5 text-slate-600">
              <b>قواعد النموذج:</b> يعيد JSON فقط (category, governorate, keywords, placeIds).
              أي معرّف لا يوجد في القاعدة المحلية يُرفض تلقائيًا (فلترة المعرّفات).
            </p>
          </div>
        )}
      </div>

      {/* استوديو الأيقونة */}
      <h2 className="mb-2 mt-5 text-[15px] font-black text-slate-800">🎨 استوديو الأيقونة</h2>
      <IconStudio />

      {/* دون اتصال */}
      <h2 className="mb-2 mt-5 text-[15px] font-black text-slate-800">📡 العمل دون اتصال</h2>
      <div className="flex flex-col gap-2">
        <Row
          icon={WifiOff}
          title="وضع عدم الاتصال (محاكاة)"
          sub="يجبر التطبيق على القاعدة المحلية والمسارات المخزّنة"
          control={<Toggle on={settings.offlineMode} onFlip={() => update({ offlineMode: !settings.offlineMode })} />}
        />
        <div className="rounded-2xl bg-white p-3.5 shadow-card ring-1 ring-slate-900/5">
          <p className="text-[12px] font-black text-slate-700">سلوك التطبيق دون اتصال:</p>
          <ul className="mt-2 flex flex-col gap-1.5 text-[12px] font-bold text-slate-500">
            <li>• البحث: القاعدة المحلية (60+ مكانًا) + المحلل الدلالي</li>
            <li>• المسارات: المخزّن أولًا ثم التقديري المحلي</li>
            <li>• الخريطة: شبكة تقريبية مع العلامات والمسار</li>
            <li>• المحفوظات والسجل: متاحة كاملة</li>
          </ul>
        </div>
      </div>

      {/* الاختبارات */}
      <h2 className="mb-2 mt-5 flex items-center gap-2 text-[15px] font-black text-slate-800">
        <FlaskConical size={17} /> الاختبارات ومعايير القبول (8)
      </h2>
      <div className="flex flex-col gap-2">
        {tests.map((t, i) => {
          const r = results[t.id];
          return (
            <div key={t.id} className="rounded-2xl bg-white p-3.5 shadow-card ring-1 ring-slate-900/5">
              <div className="flex items-start gap-2.5">
                <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-slate-100 text-[12px] font-black text-slate-600">
                  {i + 1}
                </span>
                <div className="flex-1">
                  <p className="text-[13px] font-black text-slate-800">{t.name}</p>
                  <p className="mt-0.5 text-[11px] leading-5 text-slate-500">{t.desc}</p>
                </div>
                {r === undefined && <span className="h-6 w-6 shrink-0 rounded-full bg-slate-100" />}
                {r === null && <Loader2 size={22} className="shrink-0 animate-spin text-primary-600" />}
                {r === true && <CheckCircle2 size={22} className="shrink-0 text-emerald-500" />}
                {r === false && <XCircle size={22} className="shrink-0 text-red-500" />}
              </div>
            </div>
          );
        })}
        <button
          onClick={runAll}
          disabled={testing}
          className="flex items-center justify-center gap-2 rounded-2xl bg-gradient-to-l from-primary-600 to-ink-900 py-3.5 text-[14px] font-black text-white shadow-card transition active:scale-[0.99] disabled:opacity-60"
        >
          {testing ? <Loader2 size={17} className="animate-spin" /> : <FlaskConical size={17} />}
          {testing ? "جارٍ تشغيل الاختبارات…" : Object.keys(results).length > 0 ? `إعادة التشغيل · نجح ${passed}/8` : "تشغيل كل الاختبارات"}
        </button>
        {Object.keys(results).length === 8 && !testing && (
          <div className={cn("rounded-2xl p-3.5 text-center text-[13px] font-black",
            passed === 8 ? "bg-emerald-50 text-emerald-700 ring-1 ring-emerald-200" : "bg-amber-50 text-amber-700 ring-1 ring-amber-200")}>
            {passed === 8 ? "🎉 كل معايير القبول الثمانية ناجحة!" : `نجح ${passed} من 8 — راجع العناصر بالأعلى`}
          </div>
        )}
      </div>

      {/* عن */}
      <div className="mt-5 rounded-2xl bg-white p-4 text-center shadow-card ring-1 ring-slate-900/5">
        <Info size={18} className="mx-auto text-slate-400" />
        <p className="mt-1 text-[12px] font-black text-slate-700">السحاب Cloud GPS · صُنع لخدمة العراقيين</p>
        <p className="mt-1 text-[11px] leading-5 text-slate-500">
          بيانات الخرائط © OpenStreetMap · المسارات © OSRM<br />
          المزوّدون قابلون للاستبدال من سطر واحد (registry)
        </p>
        <p className="mt-2 flex items-center justify-center gap-1 text-[11px] font-bold text-slate-400">
          <BellOff size={12} /> بلا إشعارات · بلا تتبّع · بلا حسابات
        </p>
      </div>
    </div>
  );
}
