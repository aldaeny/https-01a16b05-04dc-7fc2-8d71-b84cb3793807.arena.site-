// ─── واجهات مزوّدي البيانات + قواعد الاستبدال ───────────────
// القاعدة: أي مزوّد جديد يجب أن يطبّق نفس الواجهة ويُسجَّل هنا.
// الاستبدال يتم بتغيير سطر واحد في `activeProviders` دون المساس بالصفحات.

import type { Place, RouteResult } from "../types";

export interface SearchQuery {
  text: string;
  /** مركز البحث [lat, lon] للترتيب حسب القرب */
  near?: [number, number];
  /** فلترة محافظة */
  governorate?: string;
  limit?: number;
  signal?: AbortSignal;
}

export interface SearchProvider {
  readonly id: string;
  readonly label: string;
  readonly labelAr: string;
  /** هل يحتاج اتصالاً؟ */
  readonly needsNetwork: boolean;
  search(q: SearchQuery): Promise<Place[]>;
}

export interface RouteQuery {
  from: [number, number]; // [lat, lon]
  to: [number, number];
  fromName: string;
  toName: string;
  profile?: "driving" | "walking";
  signal?: AbortSignal;
}

export interface RoutingProvider {
  readonly id: string;
  readonly label: string;
  readonly labelAr: string;
  readonly needsNetwork: boolean;
  route(q: RouteQuery): Promise<RouteResult>;
}

// ─── سجل المزوّدين (قابل للتبديل) ───
class ProviderRegistry {
  private searchers = new Map<string, SearchProvider>();
  private routers = new Map<string, RoutingProvider>();
  activeSearch = "hybrid";
  activeRouting = "osrm";

  registerSearch(p: SearchProvider) { this.searchers.set(p.id, p); }
  registerRouting(p: RoutingProvider) { this.routers.set(p.id, p); }

  getSearch(id = this.activeSearch): SearchProvider {
    const p = this.searchers.get(id);
    if (!p) throw new Error(`Search provider not found: ${id}`);
    return p;
  }
  getRouting(id = this.activeRouting): RoutingProvider {
    const p = this.routers.get(id);
    if (!p) throw new Error(`Routing provider not found: ${id}`);
    return p;
  }
  listSearch() { return [...this.searchers.values()]; }
  listRouting() { return [...this.routers.values()]; }

  /** قاعدة الاستبدال: بدّل النشط مع التحقق من الواجهة */
  setActiveSearch(id: string) {
    if (!this.searchers.has(id)) throw new Error(`Unknown search provider: ${id}`);
    this.activeSearch = id;
  }
  setActiveRouting(id: string) {
    if (!this.routers.has(id)) throw new Error(`Unknown routing provider: ${id}`);
    this.activeRouting = id;
  }
}

export const registry = new ProviderRegistry();
