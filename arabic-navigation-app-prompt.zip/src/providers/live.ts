// ─── المزوّدون الحقيقيون: Nominatim للبحث + OSRM للمسارات + محلي ───
import type { Place, PlaceCategory, RouteResult, RouteStep } from "../types";
import { CATEGORY_AR, LOCAL_PLACES, govName } from "../data/iraq";
import { haversineKm, maneuverToAr } from "../utils/geo";
import { registry, type RouteQuery, type SearchProvider, type SearchQuery, type RoutingProvider } from "./core";

const NOMINATIM = "https://nominatim.openstreetmap.org/search";
const OSRM = "https://router.project-osrm.org/route/v1/driving";

function guessCategory(type: string, cls: string): PlaceCategory {
  const t = `${cls} ${type}`.toLowerCase();
  if (t.includes("hospital") || t.includes("clinic") || t.includes("doctors")) return "hospital";
  if (t.includes("pharmacy")) return "pharmacy";
  if (t.includes("restaurant") || t.includes("fast_food") || t.includes("kebab")) return "restaurant";
  if (t.includes("cafe")) return "cafe";
  if (t.includes("hotel") || t.includes("guest")) return "hotel";
  if (t.includes("fuel")) return "fuel";
  if (t.includes("bank") || t.includes("atm")) return "bank";
  if (t.includes("university") || t.includes("college") || t.includes("school")) return "university";
  if (t.includes("park") || t.includes("garden")) return "park";
  if (t.includes("mall") || t.includes("marketplace") || t.includes("supermarket")) return "mall";
  if (t.includes("mosque") || t.includes("shrine") || t.includes("place_of_worship")) return "mosque";
  if (t.includes("government") || t.includes("office")) return "government";
  if (t.includes("bus") || t.includes("aerodrome") || t.includes("airport") || t.includes("station")) return "station";
  if (t.includes("market") || t.includes("bazaar")) return "market";
  return "landmark";
}

function guessGov(lat: number, lon: number): string {
  // أقرب محافظة بالتقريب — مراكز معروفة
  const centers: [string, number, number][] = [
    ["baghdad", 33.3152, 44.3661], ["basra", 30.5085, 47.7804],
    ["nineveh", 36.335, 43.1189], ["erbil", 36.1911, 44.0094],
    ["sulaymaniyah", 35.5611, 45.4347], ["duhok", 36.8671, 42.9884],
    ["kirkuk", 35.4681, 44.3922], ["karbala", 32.616, 44.0249],
    ["najaf", 32.0, 44.33], ["anbar", 33.4256, 43.3009],
    ["diyala", 33.745, 44.6369], ["babil", 32.4725, 44.4311],
    ["wasit", 32.5088, 45.8199], ["dhiqar", 31.0465, 46.2572],
    ["maysan", 31.8357, 47.1448], ["muthanna", 31.325, 45.2808],
    ["qadisiyah", 31.9892, 45.2802], ["salahuddin", 34.6104, 43.6811],
  ];
  let best = "baghdad";
  let bd = Infinity;
  for (const [id, la, lo] of centers) {
    const d = haversineKm(lat, lon, la, lo);
    if (d < bd) { bd = d; best = id; }
  }
  return best;
}

// ─── Nominatim (حي) ───
export const nominatimProvider: SearchProvider = {
  id: "nominatim",
  label: "Nominatim",
  labelAr: "نوميناتيم · بحث حي",
  needsNetwork: true,
  async search(q: SearchQuery): Promise<Place[]> {
    const params = new URLSearchParams({
      format: "jsonv2",
      q: q.text,
      countrycodes: "iq",
      "accept-language": "ar",
      limit: String(q.limit ?? 10),
      addressdetails: "1",
      extratags: "1",
    });
    if (q.near) {
      params.set("lat", String(q.near[0]));
      params.set("lon", String(q.near[1]));
    }
    const res = await fetch(`${NOMINATIM}?${params.toString()}`, {
      signal: q.signal,
      headers: { Accept: "application/json" },
    });
    if (!res.ok) throw new Error(`Nominatim ${res.status}`);
    const data = (await res.json()) as Array<{
      place_id: number; display_name: string; lat: string; lon: string;
      type: string; class: string; name?: string;
    }>;
    return data.map((d) => {
      const lat = parseFloat(d.lat);
      const lon = parseFloat(d.lon);
      const short = (d.name || d.display_name.split(",")[0] || q.text).trim();
      const gov = guessGov(lat, lon);
      return {
        id: `nom-${d.place_id}`,
        name: short,
        category: guessCategory(d.type, d.class),
        governorate: gov,
        address: `${d.display_name.split(",").slice(0, 2).join("، ")} · ${govName(gov)}`,
        lat, lon,
        tags: [d.type, "نتيجة حية"],
        description: d.display_name,
        source: "nominatim" as const,
      };
    });
  },
};

// ─── محلي (يعمل دون اتصال) ───
export const localProvider: SearchProvider = {
  id: "local",
  label: "LocalDB",
  labelAr: "القاعدة المحلية · دون اتصال",
  needsNetwork: false,
  async search(q: SearchQuery): Promise<Place[]> {
    const norm = (s: string) =>
      s.replace(/[أإآ]/g, "ا").replace(/ة/g, "ه").replace(/[ى]/g, "ي").trim().toLowerCase();
    const needle = norm(q.text);
    if (!needle) return [];
    const tokens = needle.split(/\s+/).filter((t) => t.length > 1);
    const scored = LOCAL_PLACES.map((p) => {
      const hay = norm(`${p.name} ${p.nameEn ?? ""} ${p.address} ${p.description ?? ""} ${p.tags.join(" ")} ${govName(p.governorate)} ${CATEGORY_AR[p.category]}`);
      let score = 0;
      if (hay.includes(needle)) score += 100;
      for (const t of tokens) if (hay.includes(t)) score += 12;
      if (norm(p.name).startsWith(tokens[0] ?? "")) score += 25;
      if (q.governorate && q.governorate !== "all" && p.governorate === q.governorate) score += 20;
      if (q.near) {
        const d = haversineKm(q.near[0], q.near[1], p.lat, p.lon);
        score += Math.max(0, 30 - d / 8);
      }
      if (p.rating) score += p.rating * 2;
      return { p, score };
    })
      .filter((s) => s.score > 14)
      .sort((a, b) => b.score - a.score)
      .slice(0, q.limit ?? 12)
      .map((s) => s.p);
    // محاكاة زمن استجابة صغير لسلاسة الواجهة
    await new Promise((r) => setTimeout(r, 60));
    return scored;
  },
};

// ─── هجين: محلي أولًا + حي عند توفر الشبكة (الافتراضي) ───
export const hybridProvider: SearchProvider = {
  id: "hybrid",
  label: "Hybrid",
  labelAr: "هجين · محلي + حي",
  needsNetwork: false,
  async search(q: SearchQuery): Promise<Place[]> {
    const local = await localProvider.search(q);
    if (!navigator.onLine) return local;
    try {
      const live = await nominatimProvider.search({ ...q, limit: 6 });
      // دمج وإزالة التكرار بالتقارب الجغرافي
      const merged: Place[] = [...local];
      for (const l of live) {
        const dup = merged.some(
          (m) => haversineKm(m.lat, m.lon, l.lat, l.lon) < 0.25
        );
        if (!dup) merged.push(l);
      }
      return merged.slice(0, q.limit ?? 12);
    } catch {
      return local;
    }
  },
};

// ─── OSRM للمسارات (حي) ───
export const osrmProvider: RoutingProvider = {
  id: "osrm",
  label: "OSRM",
  labelAr: "أو إس آر إم · مسارات حية",
  needsNetwork: true,
  async route(q: RouteQuery): Promise<RouteResult> {
    const [flat, flon] = q.from;
    const [tlat, tlon] = q.to;
    const url =
      `${OSRM}/${flon},${flat};${tlon},${tlat}` +
      `?overview=full&geometries=geojson&steps=true&annotations=false`;
    const res = await fetch(url, { signal: q.signal });
    if (!res.ok) throw new Error(`OSRM ${res.status}`);
    const data = await res.json();
    const r = data?.routes?.[0];
    if (!r) throw new Error("لا يوجد مسار");
    const steps: RouteStep[] = [];
    for (const leg of r.legs ?? []) {
      for (const s of leg.steps ?? []) {
        const road = s.name && s.name !== "" ? s.name : s.ref;
        steps.push({
          instruction: maneuverToAr(s.maneuver?.type ?? "", s.maneuver?.modifier, road),
          distanceM: s.distance ?? 0,
          durationS: s.duration ?? 0,
          maneuver: `${s.maneuver?.type ?? ""}:${s.maneuver?.modifier ?? ""}`,
          location: s.maneuver?.location ?? [flon, flat],
          roadName: road,
        });
      }
    }
    return {
      distanceM: r.distance,
      durationS: r.duration,
      geometry: r.geometry?.coordinates ?? [[flon, flat], [tlon, tlat]],
      steps,
      provider: "osrm",
      fromName: q.fromName,
      toName: q.toName,
    };
  },
};

// ─── مسار تقديري محلي (احتياطي دون اتصال) ───
export const fallbackRouting: RoutingProvider = {
  id: "crowfly",
  label: "CrowFly",
  labelAr: "تقديري · دون اتصال",
  needsNetwork: false,
  async route(q: RouteQuery): Promise<RouteResult> {
    const [flat, flon] = q.from;
    const [tlat, tlon] = q.to;
    const straight = haversineKm(flat, flon, tlat, tlon);
    // عامل الالتفاف الحضري ~1.35
    const distKm = straight * 1.35;
    const avgKmh = straight > 80 ? 85 : 42;
    const durationS = (distKm / avgKmh) * 3600;
    // مسار منحني بسيط بين النقطتين (10 نقاط وسيطة بانحناء)
    const geom: [number, number][] = [];
    const N = 24;
    const mx = (flon + tlon) / 2;
    const my = (flat + tlat) / 2;
    const bend = Math.min(0.08, straight * 0.012);
    for (let i = 0; i <= N; i++) {
      const t = i / N;
      const lon = flon + (tlon - flon) * t + Math.sin(t * Math.PI) * bend;
      const lat = flat + (tlat - flat) * t + Math.sin(t * Math.PI) * bend * 0.6;
      geom.push([lon, lat]);
    }
    void mx; void my;
    await new Promise((r) => setTimeout(r, 120));
    return {
      distanceM: distKm * 1000,
      durationS,
      geometry: geom,
      steps: [
        { instruction: `انطلق من ${q.fromName} باتجاه ${q.toName}`, distanceM: distKm * 500, durationS: durationS / 2, maneuver: "depart:", location: [flon, flat] },
        { instruction: "تابع السير على الطريق الرئيسي (مسار تقديري دون اتصال)", distanceM: distKm * 400, durationS: durationS * 0.4, maneuver: "continue:straight", location: geom[Math.floor(N / 2)] },
        { instruction: `عند الاقتراب، اتبع اللوحات نحو ${q.toName} — لقد وصلت`, distanceM: distKm * 100, durationS: durationS * 0.1, maneuver: "arrive:", location: [tlon, tlat] },
      ],
      provider: "crowfly",
      fromName: q.fromName,
      toName: q.toName,
    };
  },
};

// تسجيل المزوّدين — لتفعيل مزوّد بديل: registry.setActiveSearch("local") مثلًا
registry.registerSearch(localProvider);
registry.registerSearch(nominatimProvider);
registry.registerSearch(hybridProvider);
registry.registerRouting(osrmProvider);
registry.registerRouting(fallbackRouting);
