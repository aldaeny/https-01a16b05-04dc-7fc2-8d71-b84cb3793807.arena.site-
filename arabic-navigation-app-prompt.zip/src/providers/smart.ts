// ─── البحث الذكي بالوصف عبر AI Gateway ────────────────────────
// القواعد:
// 1) النموذج يعيد JSON فقط: { category, governorate, keywords[], minRating, openNow, maxResults, placeIds[] }
// 2) فلترة المعرّفات: أي id يعيده النموذج يجب أن يوجد في القاعدة المحلية وإلا يُهمل.
// 3) عند غياب المفتاح/الشبكة → محلّل محلي دلالي (fallback) بنفس عقد الإخراج.

import type { AppSettings, Place, PlaceCategory } from "../types";
import { GOVERNORATES, LOCAL_PLACES, govName } from "../data/iraq";
import { haversineKm } from "../utils/geo";
import { localProvider } from "./live";

export interface SmartIntent {
  category: PlaceCategory | "any";
  governorate: string | "any";
  keywords: string[];
  minRating: number;
  openNow: boolean;
  maxResults: number;
  placeIds: string[];
  explanation: string;
}

// ─── 1) المحلّل المحلي الدلالي ───
const CATEGORY_SYNONYMS: Record<PlaceCategory, string[]> = {
  restaurant: ["مطعم", "مشويات", "كباب", "مسكوف", "اكل", "أكل", "عشاء", "غداء", "تكة", "باجه", "باجة", "سمك", "مندي", "شاورما", "بركر"],
  cafe: ["كافيه", "مقهى", "قهوه", "قهوة", "شاي", "كابتشينو", "اركيله", "شيشه", "هادئ", "هدوء"],
  hospital: ["مستشفى", "مستوصف", "طوارئ", "طبيب", "دكتور", "عياده", "اسعاف", "علاج", "مريض"],
  pharmacy: ["صيدليه", "صيدلية", "دواء", "علاج", "خافره", "خافرة"],
  mall: ["مول", "تسوق", "سوق حديث", "ماركت", "ملابس", "سينما"],
  market: ["سوق شعبي", "شعبي", "رخيص", "جمله", "عطار", "تراثي"],
  mosque: ["جامع", "مسجد", "مرقد", "زياره", "حرم", "عتبة", "صلاة", "ديني"],
  hotel: ["فندق", "اوتيل", "اقامه", "مبيت", "نوم", "زوار"],
  fuel: ["وقود", "بنزين", "محطه", "بانزين", "غاز"],
  bank: ["مصرف", "بنك", "صراف", "فلوس", "atm"],
  university: ["جامعه", "كليه", "معهد", "دراسه", "تعليم"],
  park: ["متنزه", "حديقه", "بارك", "كورنيش", "نزهه", "عوائل", "اطفال", "العاب", "نهر", "غروب"],
  government: ["دائره", "حكومي", "جواز", "جنسيه", "مرور", "بلديه", "معامله"],
  station: ["مطار", "محطه نقل", "كراج", "سفر", "طيران", "باص", "تاكسي"],
  landmark: ["اثار", "اثري", "قلعه", "سياحه", "معلم", "زقوره", "متحف", "تاريخ"],
};

const norm = (s: string) =>
  s.replace(/[أإآ]/g, "ا").replace(/ة/g, "ه").replace(/ى/g, "ي").toLowerCase();

function localParse(text: string): SmartIntent {
  const t = norm(text);
  let category: SmartIntent["category"] = "any";
  let best = 0;
  for (const [cat, words] of Object.entries(CATEGORY_SYNONYMS)) {
    let hits = 0;
    for (const w of words) if (t.includes(norm(w))) hits++;
    if (hits > best) { best = hits; category = cat as PlaceCategory; }
  }
  let governorate: SmartIntent["governorate"] = "any";
  for (const g of GOVERNORATES) {
    if (t.includes(norm(g.name.split("·")[0].trim())) || (g.nameEn && t.includes(g.nameEn.toLowerCase()))) {
      governorate = g.id;
      break;
    }
  }
  // أحياء بغداد الشهيرة → بغداد
  const baghdadAreas = ["منصور", "كراده", "اعظميه", "كاظميه", "رصافه", "كرخ", "شعب", "مدينه الصدر", "ابو نواس", "متنبي", "شورجه", "يرموك", "عامريه", "دوره"];
  if (governorate === "any" && baghdadAreas.some((a) => t.includes(norm(a)))) governorate = "baghdad";

  const keywords = text.split(/\s+/).filter((w) => w.length > 2).slice(0, 6);
  const openNow = t.includes("يعمل الان") || t.includes("مفتوح") || t.includes("خافر") || t.includes("طوارئ") || t.includes("24");
  const wantsBest = t.includes("افضل") || t.includes("احسن") || t.includes("مميز") || t.includes("نظيف") || t.includes("فخم");
  const cheap = t.includes("رخيص");

  return {
    category, governorate, keywords,
    minRating: wantsBest ? 4.2 : cheap ? 0 : 3.5,
    openNow,
    maxResults: 8,
    placeIds: [],
    explanation: `فهمت أنك تبحث عن «${category === "any" ? "أماكن" : category}»${governorate !== "any" ? ` في ${govName(governorate)}` : ""}.`,
  };
}

// ─── 2) فلترة المعرّفات — لا يمرّ إلا الموجود فعلًا ───
export function filterValidIds(ids: string[]): Place[] {
  const set = new Set(ids);
  const valid = LOCAL_PLACES.filter((p) => set.has(p.id));
  return valid;
}

// ─── 3) استدعاء AI Gateway (اختياري) ───
const SYSTEM_RULES = `أنت محلل نوايا ملاحة للعراق. أعد JSON فقط بهذا الشكل:
{"category":"restaurant|hospital|...|any","governorate":"baghdad|basra|...|any","keywords":["..."],"minRating":0,"openNow":false,"maxResults":8,"placeIds":[],"explanation":"..."}
القواعد: category من قائمة ثابتة. governorate من محافظات العراق الـ18. placeIds اتركها فارغة دائمًا (تُملأ محليًا). لا تخرج عن JSON.`;

async function gatewayParse(text: string, s: AppSettings): Promise<SmartIntent | null> {
  if (!s.aiEndpoint || !s.aiKey) return null;
  try {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 9000);
    const res = await fetch(s.aiEndpoint, {
      method: "POST",
      signal: ctrl.signal,
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${s.aiKey}`,
      },
      body: JSON.stringify({
        model: s.aiModel || "navigator-ar-1",
        system: SYSTEM_RULES,
        input: text,
        temperature: 0.1,
        max_tokens: 300,
      }),
    });
    clearTimeout(timer);
    if (!res.ok) return null;
    const data = await res.json();
    const raw = data.output ?? data.text ?? data.choices?.[0]?.message?.content ?? data.result ?? "";
    const jsonStr = typeof raw === "string" ? raw.slice(raw.indexOf("{"), raw.lastIndexOf("}") + 1) : JSON.stringify(raw);
    const parsed = JSON.parse(jsonStr);
    return {
      category: parsed.category ?? "any",
      governorate: parsed.governorate ?? "any",
      keywords: Array.isArray(parsed.keywords) ? parsed.keywords : [],
      minRating: Number(parsed.minRating ?? 0),
      openNow: Boolean(parsed.openNow),
      maxResults: Math.min(12, Number(parsed.maxResults ?? 8)),
      // فلترة المعرّفات: حتى لو أعاد النموذج ids نتحقق منها
      placeIds: Array.isArray(parsed.placeIds) ? parsed.placeIds.filter((id: string) => LOCAL_PLACES.some((p) => p.id === id)) : [],
      explanation: parsed.explanation ?? "حلّل النموذج طلبك.",
    };
  } catch {
    return null;
  }
}

// ─── الدالة الرئيسية ───
export interface SmartResult {
  intent: SmartIntent;
  places: Place[];
  via: "ai-gateway" | "local-semantic";
}

export async function smartSearch(
  text: string,
  settings: AppSettings,
  near?: [number, number]
): Promise<SmartResult> {
  // جرّب البوابة أولًا
  const aiIntent = navigator.onLine ? await gatewayParse(text, settings) : null;
  const intent = aiIntent ?? localParse(text);
  const via = aiIntent ? "ai-gateway" : "local-semantic";

  // 1) أماكن من المعرّفات المفلترة (إن وجدت)
  let results: Place[] = intent.placeIds.length > 0 ? filterValidIds(intent.placeIds) : [];

  // 2) بحث دلالي في القاعدة المحلية
  const pool = LOCAL_PLACES.filter((p) => {
    if (intent.category !== "any" && p.category !== intent.category) return false;
    if (intent.governorate !== "any" && p.governorate !== intent.governorate) return false;
    if ((p.rating ?? 0) < intent.minRating && intent.minRating > 0) {
      // اسمح ببعض المرونة: لا تستبعد كليًا إن كان قريبًا جدًا
      if (!near || haversineKm(near[0], near[1], p.lat, p.lon) > 15) return false;
    }
    if (intent.openNow && p.hours && !/24|طوارئ/.test(p.hours) && p.category !== "hospital") return false;
    return true;
  });

  // ترتيب: تطابق الكلمات + تقييم + قرب
  const scored = pool.map((p) => {
    const hay = norm(`${p.name} ${p.description ?? ""} ${p.tags.join(" ")} ${p.address}`);
    let score = (p.rating ?? 3.5) * 10;
    for (const k of intent.keywords) if (hay.includes(norm(k))) score += 18;
    const areaHit = intent.keywords.some((k) => norm(p.address).includes(norm(k)));
    if (areaHit) score += 22;
    if (near) score += Math.max(0, 40 - haversineKm(near[0], near[1], p.lat, p.lon) / 3);
    return { p, score };
  }).sort((a, b) => b.score - a.score);

  for (const s of scored) {
    if (results.length >= intent.maxResults) break;
    if (!results.some((r) => r.id === s.p.id)) results.push({ ...s.p, source: "smart" });
  }

  // 3) إن قلّت النتائج، كمّل ببحث نصي محلي
  if (results.length < 3) {
    const extra = await localProvider.search({ text, near, limit: 6 });
    for (const e of extra) {
      if (results.length >= intent.maxResults) break;
      if (!results.some((r) => r.id === e.id)) results.push(e);
    }
  }

  return { intent, places: results, via };
}
