// ─── التخزين المحلي والخصوصية ─────────────────────────────
// كل البيانات على الجهاز فقط. لا حسابات، لا سحابة، لا تتبّع.
// المفاتيح: irqnav:* — المسح الكامل متاح من الإعدادات.

import { useCallback, useEffect, useState } from "react";
import type {
  AppSettings, RouteHistoryItem,
  SavedPlace, SearchHistoryItem,
} from "../types";
import { DEFAULT_SETTINGS } from "../types";

const K = {
  saved: "irqnav:saved:v1",
  searchHist: "irqnav:search-history:v1",
  routeHist: "irqnav:route-history:v1",
  settings: "irqnav:settings:v1",
  routeCache: "irqnav:route-cache:v1",
  onboarding: "irqnav:onboarded:v1",
};

function read<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return { ...fallback as object, ...JSON.parse(raw) } as T;
  } catch {
    return fallback;
  }
}
function readArr<T>(key: string): T[] {
  try {
    const raw = localStorage.getItem(key);
    const v = raw ? JSON.parse(raw) : [];
    return Array.isArray(v) ? v : [];
  } catch {
    return [];
  }
}
function write(key: string, val: unknown) {
  try { localStorage.setItem(key, JSON.stringify(val)); } catch { /* امتلاء؟ تجاهل */ }
}

export function storageSize(): string {
  try {
    let bytes = 0;
    for (const k of Object.values(K)) bytes += (localStorage.getItem(k) ?? "").length * 2;
    if (bytes < 1024) return `${bytes} بايت`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} ك.ب`;
    return `${(bytes / 1024 / 1024).toFixed(2)} م.ب`;
  } catch { return "—"; }
}

export function clearAllData() {
  for (const k of Object.values(K)) {
    if (k === K.onboarding) continue;
    localStorage.removeItem(k);
  }
}

// ─── Hook عام ───
export function useLocalList<T>(key: string, limit = 60) {
  const [items, setItems] = useState<T[]>(() => readArr<T>(key));
  const push = useCallback((item: T) => {
    setItems((prev) => {
      const next = [item, ...prev].slice(0, limit);
      write(key, next);
      return next;
    });
  }, [key, limit]);
  const removeAt = useCallback((idx: number) => {
    setItems((prev) => {
      const next = prev.filter((_, i) => i !== idx);
      write(key, next);
      return next;
    });
  }, [key]);
  const clear = useCallback(() => {
    setItems([]);
    localStorage.removeItem(key);
  }, [key]);
  const replace = useCallback((next: T[]) => {
    setItems(next);
    write(key, next);
  }, [key]);
  return { items, push, removeAt, clear, replace };
}

export function useSettings() {
  const [settings, setSettings] = useState<AppSettings>(() => read<AppSettings>(K.settings, DEFAULT_SETTINGS));
  const update = useCallback((patch: Partial<AppSettings>) => {
    setSettings((prev) => {
      const next = { ...prev, ...patch };
      write(K.settings, next);
      return next;
    });
  }, []);
  return { settings, update };
}

export function useSaved() {
  const store = useLocalList<SavedPlace>(K.saved, 200);
  const isSaved = useCallback((id: string) => store.items.some((s) => s.id === id), [store.items]);
  return { ...store, isSaved };
}
export function useSearchHistory() { return useLocalList<SearchHistoryItem>(K.searchHist, 30); }
export function useRouteHistory() { return useLocalList<RouteHistoryItem>(K.routeHist, 30); }

// ذاكرة مسارات (offline cache): key = "flat,flon-tlat,tlon"
export function cacheRoute(key: string, route: unknown) {
  try {
    const raw = localStorage.getItem(K.routeCache);
    const obj = raw ? JSON.parse(raw) : {};
    obj[key] = { route, at: Date.now() };
    const keys = Object.keys(obj);
    if (keys.length > 25) delete obj[keys[0]];
    localStorage.setItem(K.routeCache, JSON.stringify(obj));
  } catch { /* ignore */ }
}
export function getCachedRoute<T>(key: string): T | null {
  try {
    const raw = localStorage.getItem(K.routeCache);
    const obj = raw ? JSON.parse(raw) : {};
    const hit = obj[key];
    if (!hit) return null;
    // صلاحية 7 أيام
    if (Date.now() - hit.at > 7 * 86400000) return null;
    return hit.route as T;
  } catch { return null; }
}
export function cachedRoutesCount(): number {
  try {
    const raw = localStorage.getItem(K.routeCache);
    return raw ? Object.keys(JSON.parse(raw)).length : 0;
  } catch { return 0; }
}

// حالة الاتصال
export function useOnline(forceOffline: boolean) {
  const [online, setOnline] = useState(() => navigator.onLine);
  useEffect(() => {
    const on = () => setOnline(true);
    const off = () => setOnline(false);
    window.addEventListener("online", on);
    window.addEventListener("offline", off);
    return () => {
      window.removeEventListener("online", on);
      window.removeEventListener("offline", off);
    };
  }, []);
  return forceOffline ? false : online;
}
