// ─── مسار العراق · الأنواع المركزية ─────────────────────────────
export type PlaceCategory =
  | "landmark" | "mosque" | "restaurant" | "cafe" | "mall" | "hospital"
  | "pharmacy" | "hotel" | "fuel" | "bank" | "university" | "park"
  | "government" | "station" | "market";

export interface Governorate {
  id: string;
  name: string;
  nameEn: string;
  lat: number;
  lon: number;
  zoom: number;
}

export interface Place {
  id: string;
  name: string;
  nameEn?: string;
  category: PlaceCategory;
  governorate: string; // governorate id
  address: string;
  lat: number;
  lon: number;
  phone?: string;
  rating?: number;
  reviews?: number;
  description?: string;
  tags: string[];
  hours?: string;
  source: "local" | "nominatim" | "smart";
}

export interface RouteStep {
  instruction: string;
  distanceM: number;
  durationS: number;
  maneuver: string;
  location: [number, number]; // [lon, lat]
  roadName?: string;
}

export interface RouteResult {
  distanceM: number;
  durationS: number;
  geometry: [number, number][]; // [lon,lat][]
  steps: RouteStep[];
  provider: string;
  cachedAt?: number;
  fromName: string;
  toName: string;
}

export interface SavedPlace extends Place {
  savedAt: number;
  label: "home" | "work" | "fav";
  note?: string;
}

export interface SearchHistoryItem {
  q: string;
  at: number;
  mode: "text" | "smart";
}

export interface RouteHistoryItem {
  id: string;
  fromName: string;
  toName: string;
  from: [number, number];
  to: [number, number];
  distanceM: number;
  durationS: number;
  at: number;
  provider: string;
}

export interface AppSettings {
  mapStyle: "streets" | "dark" | "relief";
  voiceGuidance: boolean;
  avoidTolls: boolean;
  avoidHighways: boolean;
  offlineMode: boolean;
  themeDark: boolean;
  units: "metric";
  aiEndpoint: string;
  aiKey: string;
  aiModel: string;
  defaultGov: string;
}

export const DEFAULT_SETTINGS: AppSettings = {
  mapStyle: "streets",
  voiceGuidance: true,
  avoidTolls: false,
  avoidHighways: false,
  offlineMode: false,
  themeDark: false,
  units: "metric",
  aiEndpoint: "",
  aiKey: "",
  aiModel: "navigator-ar-1",
  defaultGov: "baghdad",
};

export type TabId = "home" | "explore" | "saved" | "settings";
