// ─── أدوات جغرافية ───
export function haversineKm(aLat: number, aLon: number, bLat: number, bLon: number): number {
  const R = 6371;
  const dLat = ((bLat - aLat) * Math.PI) / 180;
  const dLon = ((bLon - aLon) * Math.PI) / 180;
  const s1 = Math.sin(dLat / 2);
  const s2 = Math.sin(dLon / 2);
  const c =
    s1 * s1 +
    Math.cos((aLat * Math.PI) / 180) * Math.cos((bLat * Math.PI) / 180) * s2 * s2;
  return 2 * R * Math.asin(Math.sqrt(c));
}

export function formatDistance(m: number): string {
  if (m < 950) return `${Math.round(m)} م`;
  const km = m / 1000;
  return km < 10 ? `${km.toFixed(1)} كم` : `${Math.round(km)} كم`;
}

export function formatDuration(sec: number): string {
  const m = Math.round(sec / 60);
  if (m < 1) return "أقل من دقيقة";
  if (m < 60) return `${m} دقيقة`;
  const h = Math.floor(m / 60);
  const rm = m % 60;
  return rm === 0 ? `${h} ${h === 1 ? "ساعة" : h === 2 ? "ساعتان" : "ساعات"}` : `${h} س ${rm} د`;
}

export function formatTime(iso: number): string {
  const d = new Date(iso);
  const now = new Date();
  const diff = now.getTime() - d.getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return "الآن";
  if (mins < 60) return `قبل ${mins} د`;
  const h = Math.floor(mins / 60);
  if (h < 24) return `قبل ${h} س`;
  const days = Math.floor(h / 24);
  if (days < 7) return `قبل ${days} يوم`;
  return d.toLocaleDateString("ar-IQ");
}

// WebMercator projection helpers for custom MapView
export function lonToX(lon: number, zoom: number): number {
  return ((lon + 180) / 360) * Math.pow(2, zoom);
}
export function latToY(lat: number, zoom: number): number {
  const rad = (lat * Math.PI) / 180;
  const n = Math.pow(2, zoom);
  return ((1 - Math.log(Math.tan(rad) + 1 / Math.cos(rad)) / Math.PI) / 2) * n;
}
export function xToLon(x: number, zoom: number): number {
  return (x / Math.pow(2, zoom)) * 360 - 180;
}
export function yToLat(y: number, zoom: number): number {
  const n = Math.PI - (2 * Math.PI * y) / Math.pow(2, zoom);
  return (180 / Math.PI) * Math.atan(0.5 * (Math.exp(n) - Math.exp(-n)));
}

// OSRM maneuver → Arabic instruction
export function maneuverToAr(type: string, modifier?: string, road?: string): string {
  const on = road ? ` على ${road}` : "";
  const key = `${type}:${modifier ?? ""}`;
  const map: Record<string, string> = {
    "depart:": "انطلق من نقطة البداية",
    "arrive:": "لقد وصلت إلى وجهتك",
    "turn:right": `انعطف يمينًا${on}`,
    "turn:left": `انعطف يسارًا${on}`,
    "turn:slight right": `انحرف يمينًا قليلًا${on}`,
    "turn:slight left": `انحرف يسارًا قليلًا${on}`,
    "turn:sharp right": `انعطف يمينًا بحدة${on}`,
    "turn:sharp left": `انعطف يسارًا بحدة${on}`,
    "new name:": `تابع السير${on}`,
    "continue:": `تابع السير مباشرة${on}`,
    "continue:straight": `تابع السير مباشرة${on}`,
    "roundabout:right": "ادخل الدوّار واخرج يمينًا",
    "roundabout:left": "ادخل الدوّار واخرج يسارًا",
    "roundabout:": "ادخل الدوّار ثم تابع",
    "rotary:": "ادخل الدوّار ثم تابع",
    "merge:": `ادمج مع الطريق${on}`,
    "on ramp:": `اصعد المنحدر${on}`,
    "off ramp:": `انزل من المنحدر${on}`,
    "fork:": `التزم المسار${on}`,
    "end of road:right": "عند نهاية الطريق انعطف يمينًا",
    "end of road:left": "عند نهاية الطريق انعطف يسارًا",
    "use lane:": `التزم المسار${on}`,
  };
  return map[key] ?? map[`${type}:`] ?? `تابع السير${on}`;
}

// interpolate along geometry for navigation simulation
export function pointAlong(
  geom: [number, number][],
  fraction: number
): { lon: number; lat: number; segIndex: number } {
  if (geom.length === 0) return { lon: 44.3661, lat: 33.3152, segIndex: 0 };
  if (geom.length === 1) return { lon: geom[0][0], lat: geom[0][1], segIndex: 0 };
  // weight by segment length
  const segLens: number[] = [];
  let total = 0;
  for (let i = 1; i < geom.length; i++) {
    const d = haversineKm(geom[i - 1][1], geom[i - 1][0], geom[i][1], geom[i][0]);
    segLens.push(d);
    total += d;
  }
  if (total === 0) return { lon: geom[0][0], lat: geom[0][1], segIndex: 0 };
  let target = total * Math.min(1, Math.max(0, fraction));
  for (let i = 0; i < segLens.length; i++) {
    if (target <= segLens[i] || i === segLens.length - 1) {
      const t = segLens[i] === 0 ? 0 : target / segLens[i];
      const lon = geom[i][0] + (geom[i + 1][0] - geom[i][0]) * t;
      const lat = geom[i][1] + (geom[i + 1][1] - geom[i][1]) * t;
      return { lon, lat, segIndex: i };
    }
    target -= segLens[i];
  }
  const last = geom[geom.length - 1];
  return { lon: last[0], lat: last[1], segIndex: geom.length - 2 };
}
