import { after, before, test } from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { createServer } from "vite";

let server;
let buildIconSvg;
let defaults;
let artwork;

before(async () => {
  server = await createServer({
    configFile: false,
    appType: "custom",
    server: { middlewareMode: true },
    optimizeDeps: { noDiscovery: true, entries: [] },
    logLevel: "error",
  });
  const module = await server.ssrLoadModule("/src/brand/icon.ts");
  buildIconSvg = module.buildIconSvg;
  defaults = module.DEFAULT_SPEC;
  artwork = await readFile(new URL("../src/assets/cloud-gps-mark.svg", import.meta.url), "utf8");
});

after(async () => { await server?.close(); });

const paths = (svg) => [...svg.matchAll(/<path d="([^"]+)"/g)].map((match) => match[1]);

test("exports retain the exact shared artwork paths", () => {
  assert.deepEqual(paths(buildIconSvg()), paths(artwork));
  assert.doesNotMatch(artwork, /rotate\(/);
});

test("exports have explicit square dimensions and preserve their aspect ratio", () => {
  const svg = buildIconSvg();
  assert.match(svg, /width="512" height="512" viewBox="0 0 240 240"/);
  assert.equal((svg.match(/preserveAspectRatio="xMidYMid meet"/g) ?? []).length, 2);
  const nested = svg.match(/<svg x="([^"]+)" y="([^"]+)" width="([^"]+)" height="([^"]+)"/);
  assert.ok(nested);
  assert.equal(nested[1], nested[2]);
  assert.equal(nested[3], nested[4]);
  assert.equal(Number(nested[1]) * 2 + Number(nested[3]), 240);
});

test("custom colors affect only the selected artwork layers", () => {
  const svg = buildIconSvg({ ...defaults, blue: "#112233", navy: "#445566", accent: "#778899" });
  assert.match(svg, /data-logo-part="cloud" fill="#112233"/);
  assert.match(svg, /data-logo-part="pin" fill="#445566"/);
  assert.match(svg, /data-logo-part="road" fill="#445566"/);
  assert.match(svg, /data-logo-part="diamond" fill="#778899"/);
  assert.deepEqual(paths(svg), paths(artwork));
});

test("gradient backgrounds show through the pin and road cutouts", () => {
  const svg = buildIconSvg({ ...defaults, bgId: "sky" });
  assert.match(svg, /fill="url\(#icon-bg\)"/);
  assert.doesNotMatch(svg, /data-logo-background/);
  assert.equal((svg.match(/fill-rule="evenodd"/g) ?? []).length, 2);
  assert.deepEqual(paths(svg), paths(artwork));
});

test("layer visibility never tilts or hides the location pin", () => {
  const svg = buildIconSvg({ ...defaults, cloud: false, swoosh: false, diamond: false });
  for (const layer of ["cloud", "road", "diamond"]) {
    assert.ok(svg.includes(`data-logo-part="${layer}" display="none"`));
  }
  assert.doesNotMatch(svg, /data-logo-part="pin" display="none"|rotate\(/);
});

test("invalid customization cannot inject markup or break export dimensions", () => {
  const svg = buildIconSvg({ ...defaults, blue: '"><script>', radius: Infinity, scale: NaN });
  assert.doesNotMatch(svg, /<script>|NaN|Infinity/);
  assert.match(svg, /data-logo-part="cloud" fill="#006BDF"/);
  assert.match(svg, /rx="56"/);
});

test("the browser icon references the same source artwork", async () => {
  const html = await readFile(new URL("../index.html", import.meta.url), "utf8");
  assert.match(html, /rel="icon"[^>]*href="\/src\/assets\/cloud-gps-mark\.svg(?:\?inline)?"/);
});